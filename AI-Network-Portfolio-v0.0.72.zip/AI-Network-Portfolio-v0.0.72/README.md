# AI Network Portfolio v0.0.70

**Runtime Acceptance Instrumentation** — cumulative update from v0.0.68.

## What's new
- PERF panel now provides a **MEASURE 20s** control for a reproducible FPS / render-stat sample.
- Shows average and minimum sampled FPS, p95 frame time, average draw calls and triangles, viewport and quality tier.
- **COPY REPORT** copies machine-readable JSON including browser user agent. Send this report alongside a screenshot to investigate the earlier 14 FPS observation.
- Switching quality cancels an in-progress capture to avoid mixing tiers. AUTO may still switch quality mid-capture; use HIGH/BALANCED/LOW for comparable results.
- Preserves the eight GitBlog hubs, visual reference and historical roadmap.

## Run (PowerShell)
```powershell
npm install
npm run validate
npm run build
npm run dev
```
Open http://localhost:3000. Webpack is the default to avoid the previously reported Turbopack panic.

## Browser acceptance procedure
1. Open Developer Tools Console. Verify no uncaught errors.
2. In PERF choose **HIGH**, wait 30 seconds, click **MEASURE 20s**, then **COPY REPORT**.
3. Repeat at **BALANCED** and **LOW** at the same window size, without moving the camera.
4. Verify all eight hubs, labels, river colors, and that every sidebar button opens the correct detail panel.
5. Repeat at 1920×1080, 1366×768, 390×844 and 844×390; confirm no label/HUD overlap or horizontal scroll.
6. Compare screenshots with `docs/visual-reference/official-visual-target.png`.
7. Actual GitBlog destination URLs remain unverified; do not mark navigation complete without testing real URLs.

**Verification limits:** static validation is not a substitute for an actual browser, FPS benchmark, or successful Next.js build.

## v0.0.70 — Visual fidelity correction
- Small labels above stations; subtitles hidden until selection.
- Node detail moved to right drawer; central core remains visible.
- Four bottom HUD panels now align with official target layout: real-time metrics, network traffic, render resource, active context.
- Render resource uses real WebGL telemetry; no fabricated CPU/GPU usage.
- Visual gap and browser performance still require local acceptance.


### v0.0.71
Distinct 3D symbols for all eight GitBlog hubs; fixes the REAL-TIME METRICS layout collision by overriding the legacy status grid. Check each symbol at LOW quality and confirm the four metric rings do not overlap.


### v0.0.72 — Performance Foundation & Luminous Rivers
- GTX 660 (2GB) is the reference lower-end test machine; RX 7900 GRE is the high-end comparison. No FPS guarantee without browser testing.
- LOW reduces peripheral draw calls and dynamic stream layers while retaining 8 bright core-to-hub energy rivers.
- In PowerShell: `npm install`; `npm run validate`; `npm run build`; `npm run dev`.
