'use client';
import * as THREE from 'three';
import {Canvas, useFrame, useThree} from '@react-three/fiber';
import {Sparkles} from '@react-three/drei';
import {Bloom, EffectComposer, Vignette} from '@react-three/postprocessing';
import {ReactNode, useLayoutEffect, useMemo, useRef} from 'react';

type Node3D={id:string;pos:[number,number,number];tone:string;kind:'azure'|'projects'|'fabric'|'data'|'study'|'aks'|'expertise';domains:string[]};
const nodes:Node3D[]=[
 {id:'profile',kind:'azure',pos:[-0.35,3.18,-0.6],tone:'#36baff',domains:['PROFILE','NAVIGATION','PORTFOLIO']},
 {id:'career',kind:'projects',pos:[-3.55,2.15,-0.2],tone:'#4dbbff',domains:['CAREER','NAVIGATION','PORTFOLIO']},
 {id:'projects',kind:'projects',pos:[3.55,2.15,-0.2],tone:'#ffb35b',domains:['PROJECTS','NAVIGATION','PORTFOLIO']},
 {id:'portfolio',kind:'fabric',pos:[-4.12,0.0,-0.4],tone:'#2de9c7',domains:['PORTFOLIO','NAVIGATION','PORTFOLIO']},
 {id:'github',kind:'aks',pos:[4.12,0.0,-0.4],tone:'#a47aff',domains:['GITHUB','NAVIGATION','PORTFOLIO']},
 {id:'expertise',kind:'expertise',pos:[-3.55,-2.1,-0.3],tone:'#ff6da9',domains:['EXPERTISE','NAVIGATION','PORTFOLIO']},
 {id:'training',kind:'study',pos:[-0.4,-2.82,-0.5],tone:'#ffc56c',domains:['TRAINING','NAVIGATION','PORTFOLIO']},
 {id:'archive',kind:'data',pos:[3.55,-2.1,-0.3],tone:'#56dfff',domains:['ARCHIVE','NAVIGATION','PORTFOLIO']},
];

// v0.0.22 composition correction: keep the complete network above the bottom HUD safe-zone.
const SCENE_Y_OFFSET = 0.56;
// v0.0.54: preserve the central focal corridor and spread hub anchors away from dense river junctions.

// v0.0.52 Motion Choreography — local motion remains autonomous, but every layer now has a distinct tempo family and easing envelope.
type OrbitConfig={rx:number;ry:number;phase:number;speed:number;zAmp:number;incline:number;direction:number};
const ORBITS:Record<string,OrbitConfig>={
 profile:{rx:.24,ry:.16,phase:2.62,speed:.245,zAmp:.11,incline:.04,direction:1},
 career:{rx:.24,ry:.17,phase:1.82,speed:.305,zAmp:.14,incline:-.03,direction:-1},
 projects:{rx:.23,ry:.17,phase:.43,speed:.218,zAmp:.13,incline:.04,direction:1},
 portfolio:{rx:.23,ry:.13,phase:-.36,speed:.166,zAmp:.09,incline:-.02,direction:-1},
 github:{rx:.23,ry:.18,phase:-1.36,speed:.338,zAmp:.16,incline:.05,direction:1},
 expertise:{rx:.21,ry:.145,phase:-2.63,speed:.151,zAmp:.10,incline:-.03,direction:1},
 training:{rx:.25,ry:.155,phase:3.08,speed:.192,zAmp:.095,incline:.03,direction:-1},
 archive:{rx:.20,ry:.14,phase:1.22,speed:.182,zAmp:.10,incline:.02,direction:-1},
};
const ORBIT_RUNTIME:Record<string,{angle:number;velocity:number;position:THREE.Vector3}>={};
nodes.forEach(n=>{const c=ORBITS[n.id];ORBIT_RUNTIME[n.id]={angle:c.phase,velocity:c.speed*c.direction,position:new THREE.Vector3(...n.pos)}});
function orbitPosition(id:string,t:number){const n=nodes.find(x=>x.id===id)!,c=ORBITS[id],r=ORBIT_RUNTIME[id];const a=r?.angle??(c.phase+t*c.speed*c.direction);return new THREE.Vector3(n.pos[0]+Math.cos(a)*c.rx,n.pos[1]+Math.sin(a)*c.ry+Math.sin(a*.73+c.phase)*c.incline,n.pos[2]+Math.sin(a)*c.zAmp)}
function currentNodePosition(id:string){return ORBIT_RUNTIME[id]?.position.clone()??new THREE.Vector3(...nodes.find(n=>n.id===id)!.pos)}
function IndependentOrbitController({activeId,profile}:{activeId:string|null;profile:string}){useFrame((state,delta)=>{const mobile=profile.startsWith('mobile'),t=state.clock.elapsedTime;for(const n of nodes){const c=ORBITS[n.id],r=ORBIT_RUNTIME[n.id];const focus=activeId===n.id;const personality=1+Math.sin(t*(.075+c.speed*.13)+c.phase*2.3)*.14+Math.sin(t*.033+c.phase)*.055;const focusEase=focus?.30:1;const target=c.speed*c.direction*personality*focusEase*(mobile?.72:1);r.velocity=THREE.MathUtils.damp(r.velocity,target,1.05,delta);r.angle=(r.angle+r.velocity*delta)%(Math.PI*2);r.position.copy(orbitPosition(n.id,t));}});return null}

function CoreParticles(){const ref=useRef<THREE.Points>(null!);const positions=useMemo(()=>{const a=new Float32Array(900*3);for(let i=0;i<900;i++){const u=(i+.5)/900,phi=Math.acos(1-2*u),theta=Math.PI*(1+Math.sqrt(5))*i,r=.72+(Math.sin(i*12.9898)*.5+.5)*.32;a[i*3]=r*Math.sin(phi)*Math.cos(theta);a[i*3+1]=r*Math.cos(phi);a[i*3+2]=r*Math.sin(phi)*Math.sin(theta)}return a},[]);useFrame((s,d)=>{const t=s.clock.elapsedTime;ref.current.rotation.y+=d*(.075+Math.sin(t*.11)*.012);ref.current.rotation.x=Math.sin(t*.145)*.105});return <points ref={ref}><bufferGeometry><bufferAttribute attach="attributes-position" args={[positions,3]}/></bufferGeometry><pointsMaterial color="#a9f4ff" size={.026} transparent opacity={.92} depthWrite={false} blending={THREE.AdditiveBlending}/></points>}
function Orbit({r,tube,color,rotation,speed}:{r:number;tube:number;color:string;rotation:[number,number,number];speed:number}){const ref=useRef<THREE.Mesh>(null!);useFrame((_,d)=>{ref.current.rotation.z+=d*speed});return <mesh ref={ref} rotation={rotation}><torusGeometry args={[r,tube,10,160]}/><meshBasicMaterial color={color} transparent opacity={.72} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>}
function PulseWaves(){const a=useRef<THREE.Mesh>(null!),b=useRef<THREE.Mesh>(null!);useFrame(s=>{const t=s.clock.elapsedTime;[[a.current,(t*.28)%1],[b.current,(t*.28+.5)%1]].forEach(([m,p])=>{const mesh=m as THREE.Mesh,q=p as number;mesh.scale.setScalar(1+q*2.4);(mesh.material as THREE.MeshBasicMaterial).opacity=(1-q)*.28})});return <group rotation={[Math.PI/2,0,0]}><mesh ref={a}><ringGeometry args={[1.05,1.075,128]}/><meshBasicMaterial color="#43dfff" transparent opacity={.25} side={THREE.DoubleSide} depthWrite={false}/></mesh><mesh ref={b}><ringGeometry args={[1.05,1.075,128]}/><meshBasicMaterial color="#5a8dff" transparent opacity={.2} side={THREE.DoubleSide} depthWrite={false}/></mesh></group>}
function CoreEnergyLattice(){
 const a=useRef<THREE.Group>(null!),b=useRef<THREE.Group>(null!);
 useFrame((state,delta)=>{const t=state.clock.elapsedTime;a.current.rotation.y+=delta*.16;a.current.rotation.x=Math.sin(t*.23)*.16;b.current.rotation.y-=delta*.11;b.current.rotation.z+=delta*.07});
 const nodes=useMemo(()=>Array.from({length:18},(_,i)=>{const phi=Math.acos(1-2*(i+.5)/18),theta=Math.PI*(1+Math.sqrt(5))*i;return [Math.sin(phi)*Math.cos(theta)*.55,Math.cos(phi)*.55,Math.sin(phi)*Math.sin(theta)*.55] as [number,number,number]}),[]);
 return <><group ref={a}>{nodes.map((p,i)=><mesh key={i} position={p} scale={i%3===0?.055:.032}><sphereGeometry args={[1,10,8]}/><meshBasicMaterial color={i%3===0?'#eaffff':'#56dfff'} transparent opacity={.82} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>)}</group><group ref={b} scale={1.18}><mesh><icosahedronGeometry args={[.66,1]}/><meshBasicMaterial color="#3c86ff" wireframe transparent opacity={.13} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh></group></>
}
function CoreArcBands(){const g=useRef<THREE.Group>(null!);useFrame((state,delta)=>{g.current.rotation.y-=delta*.045;g.current.rotation.z=Math.sin(state.clock.elapsedTime*.16)*.12});return <group ref={g}>{[0,1,2,3].map(i=><mesh key={i} rotation={[.45+i*.42,.18+i*.61,.35+i*.27]}><torusGeometry args={[1.12+i*.10,.008+(i%2)*.004,6,128,Math.PI*(1.05+i*.12)]}/><meshBasicMaterial color={i%2?'#6d83ff':'#72efff'} transparent opacity={.28-i*.035} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>)}</group>}
function Core(){
 const group=useRef<THREE.Group>(null!),outer=useRef<THREE.Mesh>(null!),inner=useRef<THREE.Mesh>(null!),corona=useRef<THREE.Mesh>(null!),heart=useRef<THREE.Mesh>(null!),aura=useRef<THREE.Mesh>(null!);
 useFrame((s,d)=>{const t=s.clock.elapsedTime;group.current.rotation.y+=d*(.021+Math.sin(t*.13)*.004);outer.current.scale.setScalar(1+Math.sin(t*1.47)*.028);inner.current.scale.setScalar(1+Math.sin(t*2.13+.7)*.021);heart.current.scale.setScalar(1+Math.sin(t*3.55+1.4)*.048);aura.current.scale.setScalar(1+Math.sin(t*.69+.3)*.038);corona.current.rotation.y-=d*.058;corona.current.rotation.z+=d*.033});
 return <group ref={group}>
  <pointLight color="#38dfff" intensity={11.5} distance={6.5}/><pointLight position={[0,0,1.2]} color="#6b7dff" intensity={6.2} distance={4.5}/>
  <mesh ref={aura} scale={1.34}><sphereGeometry args={[1.02,32,24]}/><meshBasicMaterial color="#167cff" transparent opacity={.042} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>
  <mesh ref={outer}><icosahedronGeometry args={[1.12,5]}/><meshPhysicalMaterial color="#0879ff" emissive="#007cff" emissiveIntensity={1.95} roughness={.07} metalness={.22} clearcoat={1} clearcoatRoughness={.06} transparent opacity={.17} transmission={.13} depthWrite={false}/></mesh>
  <mesh ref={inner}><icosahedronGeometry args={[.72,4]}/><meshPhysicalMaterial color="#04164f" emissive="#0c7cff" emissiveIntensity={4.05} roughness={.07} metalness={.38} clearcoat={1} clearcoatRoughness={.06}/></mesh>
  <mesh ref={heart}><sphereGeometry args={[.31,40,32]}/><meshBasicMaterial color="#eaffff" transparent opacity={.24} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>
  <mesh ref={corona} scale={1.17}><icosahedronGeometry args={[1.12,2]}/><meshBasicMaterial color="#63eaff" wireframe transparent opacity={.15} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>
  <mesh scale={1.08}><icosahedronGeometry args={[.92,1]}/><meshBasicMaterial color="#78a5ff" wireframe transparent opacity={.10} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>
  <CoreEnergyLattice/><CoreParticles/><CoreArcBands/>
  <Orbit r={1.33} tube={.013} color="#b9f8ff" rotation={[1.18,.25,.15]} speed={.20}/><Orbit r={1.50} tube={.018} color="#23d7ff" rotation={[.55,1.08,.35]} speed={-.13}/><Orbit r={1.70} tube={.010} color="#497cff" rotation={[1.45,.72,.9]} speed={.09}/><Orbit r={1.91} tube={.007} color="#37dfff" rotation={[.08,.35,1.12]} speed={-.055}/>
  <PulseWaves/><Sparkles count={110} scale={[3.55,3.55,2.4]} size={2.35} speed={.72} color="#72eaff"/><Sparkles count={40} scale={[2.35,2.35,1.9]} size={4.2} speed={1.15} color="#ffffff"/>
 </group>
}

function HubGlyph({kind,tone}:{kind:Node3D['kind'];tone:string}){const mat=<meshStandardMaterial color="#061d35" emissive={tone} emissiveIntensity={1.8} metalness={.35} roughness={.22}/>;if(kind==='azure')return <><mesh><octahedronGeometry args={[.48,1]}/>{mat}</mesh><mesh scale={[.62,.16,.62]} position={[0,-.46,0]}><sphereGeometry args={[.5,24,12]}/>{mat}</mesh></>;if(kind==='fabric')return <group rotation={[0,0,.18]}><mesh position={[-.17,.08,0]} scale={[.62,1,.35]}><boxGeometry args={[.55,.7,.28]}/>{mat}</mesh><mesh position={[.17,-.08,.02]} scale={[.62,1,.35]}><boxGeometry args={[.55,.7,.28]}/>{mat}</mesh></group>;if(kind==='data')return <><mesh><cylinderGeometry args={[.43,.43,.58,32]}/>{mat}</mesh>{[-.18,0,.18].map((y,i)=><mesh key={i} position={[0,y+.02,.31]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[.38,.012,6,48]}/><meshBasicMaterial color={tone}/></mesh>)}</>;if(kind==='aks')return <><mesh><dodecahedronGeometry args={[.48,0]}/>{mat}</mesh><mesh><torusKnotGeometry args={[.23,.045,72,8,2,3]}/><meshBasicMaterial color="#b9f8ff"/></mesh></>;if(kind==='projects')return <><mesh rotation={[.3,.5,.2]}><boxGeometry args={[.62,.62,.62]}/>{mat}</mesh><mesh rotation={[-.3,-.5,-.2]} scale={.62}><boxGeometry args={[.62,.62,.62]}/><meshBasicMaterial color={tone} wireframe/></mesh></>;if(kind==='expertise')return <><mesh><icosahedronGeometry args={[.48,1]}/>{mat}</mesh><mesh scale={1.25}><icosahedronGeometry args={[.48,1]}/><meshBasicMaterial color={tone} wireframe transparent opacity={.38}/></mesh></>;return <><mesh position={[-.2,0,0]} rotation={[0,.18,.08]}><boxGeometry args={[.34,.62,.08]}/>{mat}</mesh><mesh position={[.2,0,0]} rotation={[0,-.18,-.08]}><boxGeometry args={[.34,.62,.08]}/>{mat}</mesh></>}

type TopologyPoint={p:THREE.Vector3;label:string;micro:THREE.Vector3[]};
function topologyFor(n:Node3D,index:number):TopologyPoint[]{return n.domains.map((label,i)=>{const a=(i/6)*Math.PI*2+index*.31,r=.92+(i%2)*.14;const p=new THREE.Vector3(Math.cos(a)*r,Math.sin(a)*(.68+(i%3)*.05),(i%2?-.20:.22));const micro=Array.from({length:4},(_,m)=>{const ma=a+(m-1.5)*.25,mr=.27+(m%2)*.07;return p.clone().add(new THREE.Vector3(Math.cos(ma)*mr,Math.sin(ma)*mr,(m-1.5)*.07))});return {p,label,micro}})}
function LocalTopology({n,index}:{n:Node3D;index:number}){const topo=useMemo(()=>topologyFor(n,index),[n,index]);return <>{topo.map((s,i)=><group key={`${n.id}-topology-${i}`}><line><bufferGeometry setFromPoints={[new THREE.Vector3(),s.p]}/><lineBasicMaterial color={n.tone} transparent opacity={.22}/></line><mesh position={s.p}><icosahedronGeometry args={[.055+(i%3)*.008,1]}/><meshBasicMaterial color={i%3===0?'#ffffff':n.tone}/></mesh><mesh position={s.p} rotation={[Math.PI/2,0,i*.37]}><torusGeometry args={[.14+(i%2)*.018,.006,5,28]}/><meshBasicMaterial color={n.tone} transparent opacity={.26} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>{s.micro.map((m,j)=><group key={j}><line><bufferGeometry setFromPoints={[s.p,m]}/><lineBasicMaterial color={n.tone} transparent opacity={.105}/></line><mesh position={m}><boxGeometry args={[.035,.035,.035]}/><meshBasicMaterial color={j===0?'#dffcff':n.tone} transparent opacity={.58}/></mesh></group>)}</group>)}</>}
// v0.0.47 Micro Network Detail — batched data pulses make each local topology read as an active relay system.
function HubMicroTraffic({n,index}:{n:Node3D;index:number}){
 const topo=useMemo(()=>topologyFor(n,index),[n,index]);
 const edges=useMemo(()=>topo.flatMap((s,si)=>s.micro.map((m,mi)=>({a:s.p,b:m,phase:(si*.173+mi*.241+index*.113)%1,rate:.18+(mi%3)*.035}))),[topo,index]);
 const ref=useRef<THREE.InstancedMesh>(null!),dummy=useMemo(()=>new THREE.Object3D(),[]),last=useRef(0);
 useFrame(st=>{const t=st.clock.elapsedTime;if(t-last.current<1/30)return;last.current=t;const mesh=ref.current;if(!mesh)return;edges.forEach((e,i)=>{const q=(e.phase+t*e.rate)%1;dummy.position.lerpVectors(e.a,e.b,q);const pulse=.018*(.72+.28*Math.sin(Math.PI*q));dummy.scale.setScalar(pulse);dummy.rotation.set(t*.35+i*.07,t*.22,0);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix)});mesh.instanceMatrix.needsUpdate=true});
 return <instancedMesh ref={ref} args={[undefined,undefined,edges.length]} frustumCulled><octahedronGeometry args={[1,0]}/><meshBasicMaterial color={n.tone} transparent opacity={.86} depthWrite={false} blending={THREE.AdditiveBlending}/></instancedMesh>
}
// v0.0.34 Local Moon System — each hub owns three moons with independent radius, phase, inclination and angular velocity.
// v0.0.43 Hub Identity Pass I — the first four portfolio domains now carry distinct structural silhouettes.
// v0.0.44 Hub Identity Pass II — AKS / AI Study / Expertise complete the seven-hub identity system.
// v0.0.45 Moon & Satellite System 2.0 — hub-specific satellite silhouettes, eccentric local orbits and visible trails.
function HubIdentityDetails({kind,tone}:{kind:Node3D['kind'];tone:string}){
 const g=useRef<THREE.Group>(null!);useFrame((_,d)=>{if(g.current)g.current.rotation.y+=d*(kind==='fabric'?.12:kind==='data'?.055:.075)});
 if(kind==='azure')return <group ref={g}>{[0,1,2].map(i=><mesh key={i} rotation={[0,i*Math.PI/3,.28+i*.08]}><torusGeometry args={[.50+i*.105,.012,6,64,Math.PI*1.25]}/><meshBasicMaterial color={i===1?'#d8fbff':tone} transparent opacity={.42-i*.07} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>)}<mesh position={[0,-.54,0]} scale={[1,.18,1]}><cylinderGeometry args={[.48,.62,.18,6]}/><meshStandardMaterial color="#041726" emissive={tone} emissiveIntensity={.65} metalness={.78} roughness={.2}/></mesh></group>;
 if(kind==='projects')return <group ref={g}>{[-1,0,1].map((x,i)=><mesh key={i} position={[x*.34,(i-1)*.12,0]} rotation={[.22,i*.52,.15]}><boxGeometry args={[.26,.26,.26]}/><meshPhysicalMaterial color="#071524" emissive={tone} emissiveIntensity={.82} metalness={.7} roughness={.18} clearcoat={1}/></mesh>)}{[-1,1].map((z,i)=><mesh key={'r'+i} position={[0,0,z*.22]} rotation={[Math.PI/2,0,.35]}><torusGeometry args={[.57,.012,6,64]}/><meshBasicMaterial color={i?'#ffd6a3':tone} transparent opacity={.42} depthWrite={false}/></mesh>)}</group>;
 if(kind==='fabric')return <group ref={g}>{[-.34,0,.34].map((x,i)=><mesh key={i} position={[x,(i-1)*.06,0]} rotation={[0,0,(i-1)*-.16]}><boxGeometry args={[.22,.82,.18]}/><meshPhysicalMaterial color="#031a25" emissive={i===1?'#d9ffff':tone} emissiveIntensity={1.0} metalness={.54} roughness={.16} clearcoat={1}/></mesh>)}<mesh rotation={[Math.PI/2,0,0]}><torusGeometry args={[.58,.018,6,72]}/><meshBasicMaterial color={tone} transparent opacity={.55} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh></group>;
 if(kind==='data')return <group ref={g}>{[-.34,0,.34].map((y,i)=><mesh key={i} position={[0,y,0]} scale={[1-i*.08,.16,1-i*.08]}><cylinderGeometry args={[.50,.50,.18,32]}/><meshPhysicalMaterial color="#061827" emissive={tone} emissiveIntensity={.72+i*.12} metalness={.72} roughness={.2} clearcoat={.8}/></mesh>)}{[0,1,2,3].map(i=>{const a=i*Math.PI/2;return <mesh key={'p'+i} position={[Math.cos(a)*.64,.03,Math.sin(a)*.64]}><boxGeometry args={[.09,.26,.09]}/><meshBasicMaterial color={tone} transparent opacity={.62}/></mesh>})}</group>;
 // v0.0.44 Hub Identity Pass II — AKS is a control-plane wheel: six workload cells around a bright scheduler core.
 if(kind==='aks')return <group ref={g}><mesh><cylinderGeometry args={[.19,.19,.24,6]}/><meshPhysicalMaterial color="#06192d" emissive="#dff8ff" emissiveIntensity={1.35} metalness={.74} roughness={.14} clearcoat={1}/></mesh>{Array.from({length:6},(_,i)=>{const a=i/6*Math.PI*2;return <group key={i} position={[Math.cos(a)*.52,Math.sin(a)*.52,0]} rotation={[0,0,a]}><mesh><cylinderGeometry args={[.11,.11,.16,6]}/><meshPhysicalMaterial color="#06172a" emissive={tone} emissiveIntensity={1.0} metalness={.7} roughness={.18} clearcoat={1}/></mesh><mesh position={[-.20,0,0]} rotation={[0,0,Math.PI/2]}><boxGeometry args={[.28,.025,.025]}/><meshBasicMaterial color={tone} transparent opacity={.55}/></mesh></group>})}<mesh rotation={[Math.PI/2,0,0]}><torusGeometry args={[.52,.022,6,72]}/><meshBasicMaterial color={tone} transparent opacity={.72} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh></group>;
 // AI Study uses an open-book / neural-learning silhouette: paired knowledge panels with a pulsing neural nucleus.
 if(kind==='study')return <group ref={g}><mesh position={[-.25,0,0]} rotation={[0,.18,.12]}><boxGeometry args={[.36,.64,.07]}/><meshPhysicalMaterial color="#090d2b" emissive={tone} emissiveIntensity={.82} metalness={.38} roughness={.22} clearcoat={1}/></mesh><mesh position={[.25,0,0]} rotation={[0,-.18,-.12]}><boxGeometry args={[.36,.64,.07]}/><meshPhysicalMaterial color="#090d2b" emissive={tone} emissiveIntensity={.82} metalness={.38} roughness={.22} clearcoat={1}/></mesh><mesh><octahedronGeometry args={[.17,1]}/><meshBasicMaterial color="#e8e5ff" transparent opacity={.86} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>{[-1,0,1].map((x,i)=><mesh key={i} position={[x*.36,.37-(i%2)*.12,.05]}><sphereGeometry args={[.055,10,8]}/><meshBasicMaterial color={i===1?'#ffffff':tone}/></mesh>)}<mesh rotation={[Math.PI/2.5,.2,.15]}><torusGeometry args={[.58,.012,6,72,Math.PI*1.55]}/><meshBasicMaterial color={tone} transparent opacity={.48} depthWrite={false}/></mesh></group>;
 // Expertise is a faceted knowledge nexus with six specialist facets feeding a mint core.
 if(kind==='expertise')return <group ref={g}><mesh><icosahedronGeometry args={[.31,1]}/><meshPhysicalMaterial color="#061d20" emissive={tone} emissiveIntensity={1.2} metalness={.55} roughness={.14} clearcoat={1}/></mesh>{Array.from({length:6},(_,i)=>{const a=i/6*Math.PI*2,r=.55;return <group key={i} position={[Math.cos(a)*r,Math.sin(a)*r*.72,(i%2?-.12:.12)]}><mesh rotation={[a*.35,a,.25]}><tetrahedronGeometry args={[.12,0]}/><meshPhysicalMaterial color="#071c22" emissive={tone} emissiveIntensity={.92} metalness={.62} roughness={.18} clearcoat={1}/></mesh><mesh position={[-Math.cos(a)*.27,-Math.sin(a)*.19,0]} rotation={[0,0,a]}><boxGeometry args={[.30,.018,.018]}/><meshBasicMaterial color={tone} transparent opacity={.45}/></mesh></group>})}<mesh rotation={[Math.PI/2.15,.25,.2]}><torusGeometry args={[.66,.014,6,72]}/><meshBasicMaterial color="#a8ffe6" transparent opacity={.56} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh></group>;
 return null;
}
function HubSatellites({tone,index}:{tone:string;index:number}){
 const roots=useRef<THREE.Group[]>([]);
 // v0.0.45 Moon & Satellite System 2.0 — each hub gets a distinct local satellite family.
 const families=['cloud','module','ribbon','archive','pod','neural','facet'] as const;
 const family=families[index%families.length];
 const cfg=useMemo(()=>[0,1,2].map(i=>({
  r:.90+i*.22+(index%2)*.035,
  phase:index*.67+i*2.17,
  speed:(.145+i*.061)*(i===1?-1:1)*(1+(index%3)*.07),
  incline:.24+i*.13+(index%2)*.035,
  z:.10+(i-1)*.18,
  size:.095+i*.018+(index%3)*.004,
  eccentricity:.92+(i%2)*.12
 })),[index]);
 useFrame((s)=>{const t=s.clock.elapsedTime;roots.current.forEach((g,i)=>{if(!g)return;const c=cfg[i],a=c.phase+t*c.speed;g.position.set(Math.cos(a)*c.r*c.eccentricity,Math.sin(a)*c.r*c.incline,c.z+Math.sin(a*.73+c.phase)*.18);g.rotation.y=t*(.30+i*.09)*(i===1?-1:1);g.rotation.x=Math.sin(t*.23+i)*.24;g.rotation.z=-a*.18})});
 const body=(c:any,i:number)=>{
  const mat=<meshPhysicalMaterial color={i===0?'#e8fbff':'#9edfff'} emissive={tone} emissiveIntensity={1.35+i*.12} metalness={.42} roughness={.14} clearcoat={1} clearcoatRoughness={.08}/>;
  if(family==='cloud')return <group><mesh>{mat}<icosahedronGeometry args={[c.size,2]}/></mesh><mesh scale={[1.7,.38,1]} rotation={[.3,.2,.4]}><torusGeometry args={[c.size*1.1,.012,6,32]}/><meshBasicMaterial color={tone}/></mesh></group>;
  if(family==='module')return <group><mesh>{mat}<boxGeometry args={[c.size*1.55,c.size*.92,c.size*1.15]}/></mesh><mesh position={[c.size*1.05,0,0]}><boxGeometry args={[c.size*.75,c.size*.10,c.size*.9]}/><meshBasicMaterial color={tone}/></mesh></group>;
  if(family==='ribbon')return <group><mesh>{mat}<octahedronGeometry args={[c.size,1]}/></mesh><mesh rotation={[Math.PI/2.2,.2,0]}><torusGeometry args={[c.size*1.65,.009,5,36,Math.PI*1.55]}/><meshBasicMaterial color={tone}/></mesh></group>;
  if(family==='archive')return <group><mesh>{mat}<cylinderGeometry args={[c.size*1.05,c.size*1.05,c.size*.72,18]}/></mesh>{[-.28,.28].map((y,j)=><mesh key={j} position={[0,c.size*y,0]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[c.size*1.08,.008,5,28]}/><meshBasicMaterial color={tone}/></mesh>)}</group>;
  if(family==='pod')return <group><mesh>{mat}<dodecahedronGeometry args={[c.size,0]}/></mesh>{[0,1,2].map(j=><mesh key={j} rotation={[j*.9,j*.7,j*.4]}><torusGeometry args={[c.size*1.38,.007,5,28]}/><meshBasicMaterial color={tone} transparent opacity={.72}/></mesh>)}</group>;
  if(family==='neural')return <group><mesh>{mat}<icosahedronGeometry args={[c.size*.82,1]}/></mesh>{[0,1,2,3].map(j=>{const a=j*Math.PI/2;return <mesh key={j} position={[Math.cos(a)*c.size*1.35,Math.sin(a)*c.size*1.35,0]}><sphereGeometry args={[c.size*.22,8,6]}/><meshBasicMaterial color={tone}/></mesh>})}</group>;
  return <group><mesh>{mat}<tetrahedronGeometry args={[c.size*1.05,1]}/></mesh><mesh rotation={[.8,.2,.5]}><torusGeometry args={[c.size*1.45,.008,5,30]}/><meshBasicMaterial color={tone}/></mesh></group>;
 };
 return <group>{cfg.map((c,i)=><group key={i}>
  <mesh rotation={[Math.PI/2.25+i*.16,index*.11,0]}><torusGeometry args={[c.r,.006,5,96]}/><meshBasicMaterial color={tone} transparent opacity={.17} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>
  <group ref={g=>{if(g)roots.current[i]=g;else roots.current.splice(i,1)}}>{body(c,i)}<mesh rotation={[Math.PI/2.25+i*.17,0,0]}><torusGeometry args={[c.size*2.0,.006,5,36]}/><meshBasicMaterial color={tone} transparent opacity={.68} depthWrite={false}/></mesh><pointLight color={tone} intensity={.32} distance={1.05}/></group>
 </group>)}</group>
}
function EcosystemFocusAura({tone,enabled}:{tone:string;enabled:boolean}){
 const group=useRef<THREE.Group>(null!);const outer=useRef<THREE.Mesh>(null!);const inner=useRef<THREE.Mesh>(null!);
 useFrame(({clock},dt)=>{if(!group.current)return;const t=clock.elapsedTime;group.current.rotation.z+=dt*.18;group.current.rotation.y=Math.sin(t*.31)*.13;const target=enabled?1:0;const v=THREE.MathUtils.damp(group.current.scale.x,target,5,dt);group.current.scale.setScalar(Math.max(.001,v));if(outer.current)outer.current.rotation.z-=dt*.36;if(inner.current)inner.current.rotation.z+=dt*.48});
 return <group ref={group} scale={.001}><mesh ref={outer} rotation={[Math.PI/2.45,0,.35]}><torusGeometry args={[1.38,.018,6,96]}/><meshBasicMaterial color={tone} transparent opacity={.64} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh><mesh ref={inner} rotation={[Math.PI/2.15,.3,0]}><torusGeometry args={[1.13,.012,6,96]}/><meshBasicMaterial color="#d6faff" transparent opacity={.48} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh><mesh><sphereGeometry args={[1.04,24,16]}/><meshBasicMaterial color={tone} transparent opacity={.045} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh></group>
}
// v0.0.60: compact orbital station architecture, tied to the 8 GitBlog hubs.
// The structural silhouette is deliberately distinct from the old wireframe sphere.
function OrbitalStation({tone,index}:{tone:string;index:number}){
 const rotor=useRef<THREE.Group>(null!);
 const identity=index%8;
 useFrame((state,delta)=>{if(rotor.current){rotor.current.rotation.y+=delta*(.035+index*.003);rotor.current.rotation.z=Math.sin(state.clock.elapsedTime*.26+index)*.009;}});
 // Eight readable silhouettes, with a shared low-cost dock chassis.
 const petals=[4,6,3,8,5,7,6,4][identity];
 const armLength=[.33,.29,.42,.28,.36,.31,.25,.4][identity];
 return <group position={[0,-.49,0]}>
  <mesh position={[0,-.12,0]}><cylinderGeometry args={[.65,.72,.13,12]}/><meshStandardMaterial color="#182d40" metalness={.88} roughness={.3} emissive={tone} emissiveIntensity={.10}/></mesh>
  <mesh position={[0,-.015,0]}><cylinderGeometry args={[.55,.59,.08,12]}/><meshStandardMaterial color="#091827" metalness={.92} roughness={.22}/></mesh>
  <mesh position={[0,.038,0]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[.61,.022,6,48]}/><meshBasicMaterial color={tone} toneMapped={false}/></mesh>
  <mesh position={[0,-.20,0]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[.70,.014,5,48]}/><meshBasicMaterial color={tone} transparent opacity={.62} depthWrite={false}/></mesh>
  <group ref={rotor}>{Array.from({length:petals},(_,i)=>{const a=i*Math.PI*2/petals;return <group key={i} position={[Math.cos(a)*.62,-.035,Math.sin(a)*.62]} rotation={[0,-a,0]}>
   <mesh position={[armLength*.33,0,0]}><boxGeometry args={[armLength,.085,.13]}/><meshStandardMaterial color="#233e51" metalness={.88} roughness={.25}/></mesh>
   <mesh position={[armLength*.79,.018,0]}><boxGeometry args={[.19,.16,.24]}/><meshStandardMaterial color="#0e2537" metalness={.82} roughness={.27} emissive={tone} emissiveIntensity={.24}/></mesh>
   <mesh position={[armLength*.8,.105,0]}><boxGeometry args={[.11,.014,.15]}/><meshBasicMaterial color={tone} toneMapped={false}/></mesh>
  </group>})}</group>
  {identity===0||identity===5?<group>{[-1,1].map(side=><mesh key={side} position={[side*.3,.22,0]}><cylinderGeometry args={[.025,.035,.38,6]}/><meshStandardMaterial color="#7292a3" metalness={.9} roughness={.25}/></mesh>)}</group>:null}
  {identity===1||identity===4?<group>{[-1,1].map(side=><mesh key={side} position={[side*.31,.14,0]} rotation={[0,0,side*.24]}><boxGeometry args={[.16,.27,.1]}/><meshStandardMaterial color="#304d60" metalness={.88} roughness={.22}/></mesh>)}</group>:null}
  {identity===2||identity===7?<mesh position={[0,.15,0]}><boxGeometry args={[.42,.19,.34]}/><meshStandardMaterial color="#203b4e" metalness={.88} roughness={.26} emissive={tone} emissiveIntensity={.16}/></mesh>:null}
  {identity===3||identity===6?<mesh position={[0,.13,0]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[.35,.055,6,32]}/><meshStandardMaterial color="#254b5d" metalness={.9} roughness={.23} emissive={tone} emissiveIntensity={.32}/></mesh>:null}
  <mesh position={[0,.13,0]}><cylinderGeometry args={[.22,.3,.12,12]}/><meshStandardMaterial color="#102e42" metalness={.88} roughness={.22} emissive={tone} emissiveIntensity={.35}/></mesh>
 </group>;
}
// v0.0.71: eight recognizable three-dimensional menu identities, not generic glowing spheres.
function GitBlogEmblem({id,tone}:{id:string;tone:string}){
 const metal=<meshStandardMaterial color="#294b60" metalness={.42} roughness={.32} emissive={tone} emissiveIntensity={1.35}/>;
 const bright=<meshBasicMaterial color={tone} toneMapped={false}/>;
 const block=(key:string,pos:[number,number,number],size:[number,number,number],rotation:[number,number,number]=[0,0,0])=><mesh key={key} position={pos} rotation={rotation}><boxGeometry args={size}/>{metal}</mesh>;
 const node=(key:string,pos:[number,number,number],r=.075)=><mesh key={key} position={pos}><sphereGeometry args={[r,12,10]}/>{bright}</mesh>;
 return <group position={[0,.30,.52]} scale={1.45}>
  <mesh position={[0,0,-.12]}><cylinderGeometry args={[.34,.39,.12,8]}/><meshStandardMaterial color="#112a3c" emissive={tone} emissiveIntensity={.48} metalness={.5} roughness={.36}/></mesh>
  {id==='profile'&&<group>{node('head',[0,.15,.15],.115)}<mesh position={[0,-.105,.12]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[.23,.075,8,24,Math.PI]}/>{bright}</mesh>{block('base',[0,-.24,.05],[.39,.065,.13])}</group>}
  {id==='career'&&<group>{[0,1,2].map(i=>block('tier'+i,[-.21+i*.21,-.15+i*.075,.08],[.16,.24+i*.12,.19]))}{block('bridge',[0,-.24,.13],[.57,.065,.15])}{node('peak',[.21,.22,.12],.055)}</group>}
  {id==='projects'&&<group>{[[-.19,.10,.12],[.18,.11,.12],[0,-.18,.2]].map((p,i)=>block('module'+i,p as [number,number,number],[.24,.22,.22],[.08,i*.3,0]))}{node('join',[0,.06,.29],.065)}</group>}
  {id==='portfolio'&&<group>{[0,1,2].map(i=>block('sheet'+i,[-.10+i*.09,.13-i*.11,.11+i*.055],[.42,.26,.065],[0,0,-.07]))}{block('line',[.05,.11,.33],[.23,.025,.025])}</group>}
  {id==='github'&&<group>{node('top',[0,.22,.15],.08)}{node('left',[-.21,-.12,.15],.08)}{node('right',[.21,-.12,.15],.08)}{block('stem',[0,.02,.15],[.055,.33,.065])}{block('branchL',[-.11,-.10,.15],[.23,.045,.06],[0,0,-.36])}{block('branchR',[.11,-.10,.15],[.23,.045,.06],[0,0,.36])}</group>}
  {id==='expertise'&&<group>{[[-.18,.14,.14],[.17,.18,.15],[-.24,-.12,.16],[.14,-.17,.16],[0,.01,.30]].map((p,i)=>node('neuron'+i,p as [number,number,number],.07))}{[[-.10,.15,.17],[.08,.08,.22],[-.12,-.10,.19],[.04,-.13,.20]].map((p,i)=>block('synapse'+i,p as [number,number,number],[.22,.027,.035],[0,0,i%2?.65:-.55]))}</group>}
  {id==='training'&&<group>{block('cap',[0,.07,.12],[.52,.085,.35],[0,0,.05])}{block('crown',[0,-.05,.11],[.31,.17,.22])}{block('tassel',[.26,-.14,.12],[.027,.24,.03])}{node('bead',[.26,-.26,.12],.045)}</group>}
  {id==='archive'&&<group>{block('cabinet',[0,-.07,.08],[.50,.38,.30])}{block('lid',[0,.17,.10],[.59,.075,.35])}{block('slot',[0,-.04,.26],[.22,.055,.035])}{block('handle',[0,-.15,.26],[.13,.035,.04])}</group>}
 </group>;
}
// v0.0.61: a purposeful orbital relay replaces the ambiguous bare diamond outline.
// A diamond-shaped metal frame, luminous communication core, antennae and live beacon orbit locally.
function OrbitalRelaySatellite({tone,index}:{tone:string;index:number}){
 const root=useRef<THREE.Group>(null!);
 useFrame(({clock},dt)=>{if(!root.current)return;const t=clock.elapsedTime;
   const phase=t*(.22+index*.012)+index*.73;
   root.current.position.set(-1.19+Math.cos(phase)*.13,1.00+Math.sin(phase)*.11,.48+Math.sin(phase*.8)*.12);
   root.current.rotation.set(.20+Math.sin(t*.18+index)*.12,Math.sin(t*.24+index)*.3,Math.sin(t*.31+index)*.13);
 });
 return <group ref={root} scale={.57}>
   <mesh><cylinderGeometry args={[.43,.43,.11,6]}/><meshStandardMaterial color="#071522" emissive={tone} emissiveIntensity={.14} metalness={.88} roughness={.25} transparent opacity={.85}/></mesh>
   <mesh position={[0,0,.058]}><torusGeometry args={[.38,.025,6,6]}/><meshBasicMaterial color={tone} transparent opacity={.65} depthWrite={false}/></mesh>
   <mesh position={[0,0,.15]} rotation={[0,0,Math.PI/4]}><octahedronGeometry args={[.21,1]}/><meshBasicMaterial color={tone} toneMapped={false}/></mesh>
   <mesh position={[0,0,.27]}><sphereGeometry args={[.095,12,8]}/><meshBasicMaterial color="#e4fcff" toneMapped={false}/></mesh>
   {Array.from({length:6},(_,i)=>{const a=i*Math.PI/3;return <group key={`relay-fin-${i}`} position={[Math.cos(a)*.42,Math.sin(a)*.42,0]} rotation={[0,0,a]}><mesh><boxGeometry args={[.13,.055,.09]}/><meshStandardMaterial color="#142f43" metalness={.88} roughness={.22} emissive={tone} emissiveIntensity={.22}/></mesh><mesh position={[.06,0,.055]}><boxGeometry args={[.035,.025,.012]}/><meshBasicMaterial color={tone} toneMapped={false}/></mesh></group>})}
   {[-1,1].map((s)=><group key={s}><mesh position={[s*.55,0,0]}><boxGeometry args={[.36,.035,.035]}/><meshStandardMaterial color="#24435b" metalness={.8} roughness={.2}/></mesh><mesh position={[s*.75,0,0]}><sphereGeometry args={[.075,10,8]}/><meshBasicMaterial color={tone} toneMapped={false}/></mesh></group>)}
   <mesh rotation={[Math.PI/2,0,0]}><torusGeometry args={[.68,.014,5,56]}/><meshBasicMaterial color={tone} transparent opacity={.46} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>
 </group>;
}
function Hub({n,index,activeId,quality}:{n:Node3D;index:number;activeId:string|null;quality:'HIGH'|'BALANCED'|'LOW'}){const g=useRef<THREE.Group>(null!),shell=useRef<THREE.Mesh>(null!),ringA=useRef<THREE.Mesh>(null!),ringB=useRef<THREE.Mesh>(null!),station=useRef<THREE.Group>(null!);useFrame((s,d)=>{const t=s.clock.elapsedTime;const tempo=[.82,1.08,.74,.91,1.16,.68,.97][index]??1;g.current.rotation.y+=d*(.020+index*.0018)*tempo;g.current.position.copy(currentNodePosition(n.id));g.current.position.y+=Math.sin(t*(.38+index*.021)+index*1.31)*.018;g.current.rotation.z=Math.sin(t*(.21+index*.013)+index)*.009;ringA.current.rotation.z+=d*(.105+index*.005)*tempo;ringB.current.rotation.z-=d*(.064+index*.0035)/tempo;station.current.rotation.y-=d*(.046+index*.003)*tempo;shell.current.scale.setScalar(1+Math.sin(t*(.78+index*.037)+index*.7)*.026)});const focused=!activeId||activeId===n.id;return <group ref={g} position={currentNodePosition(n.id)} scale={focused?(activeId?1.10:1):.94}>{quality!=='LOW'&&<pointLight color={n.tone} intensity={focused?1.15:.55} distance={2.3}/>}<mesh ref={shell}><icosahedronGeometry args={[.68,4]}/><meshPhysicalMaterial color="#020c18" emissive={n.tone} emissiveIntensity={.50} metalness={.58} roughness={.11} clearcoat={1} clearcoatRoughness={.08} transparent opacity={.075} transmission={.06} depthWrite={false}/></mesh><mesh scale={1.08}><icosahedronGeometry args={[.66,2]}/><meshBasicMaterial color={n.tone} wireframe transparent opacity={.012}/></mesh><mesh scale={1.22}><sphereGeometry args={[.66,28,20]}/><meshBasicMaterial color={n.tone} transparent opacity={.028} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh><group ref={station}>{Array.from({length:5},(_,i)=>{const a=i/5*Math.PI*2,r=.73+(i%2)*.08;return <mesh key={i} position={[Math.cos(a)*r,-.12+(i%3)*.10,Math.sin(a)*r*.52]} rotation={[0,-a,0]}><boxGeometry args={[.075,.18+(i%4)*.035,.075]}/><meshStandardMaterial color="#071827" emissive={n.tone} emissiveIntensity={1.22} metalness={.40} roughness={.2}/></mesh>})}</group><group>{focused&&activeId===n.id&&<mesh><sphereGeometry args={[.84,24,16]}/><meshBasicMaterial color={n.tone} transparent opacity={.10} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>}<GitBlogEmblem id={n.id} tone={n.tone}/><OrbitalStation tone={n.tone} index={index}/><OrbitalRelaySatellite tone={n.tone} index={index}/></group><mesh ref={ringA} rotation={[Math.PI/2.35,.15,.12]}><torusGeometry args={[.74,.026,8,96]}/><meshBasicMaterial color={n.tone} transparent opacity={.94} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh><mesh ref={ringB} rotation={[Math.PI/2.05,-.32,.18]}><torusGeometry args={[.91,.012,6,96]}/><meshBasicMaterial color="#e9fdff" transparent opacity={.52} depthWrite={false}/></mesh><mesh rotation={[Math.PI/2,0,0]} position={[0,-.69,0]}><ringGeometry args={[.43,.82,96]}/><meshBasicMaterial color={n.tone} transparent opacity={.15} side={THREE.DoubleSide}/></mesh><EcosystemFocusAura tone={n.tone} enabled={activeId===n.id}/><HubSatellites tone={n.tone} index={index}/>{focused&&quality!=='LOW'&&<LocalTopology n={n} index={index}/>} {quality!=='LOW'&&<HubMicroTraffic n={n} index={index}/>}<Sparkles count={quality==='LOW'?4:quality==='BALANCED'?9:14} scale={[1.9,1.6,1.2]} size={2.0} speed={.38+index*.02} color={n.tone}/></group>}

type Highway={curve:THREE.CatmullRomCurve3;color:string;phase:number;width:number;speed:number;opacity:number;hubId:string;laneIndex:number;hubIndex:number};
function makeHighways(){const highways:Highway[]=[];nodes.forEach((n,k)=>{const end=new THREE.Vector3(...n.pos),dir=end.clone().normalize(),start=dir.clone().multiplyScalar(1.42),anchor=end.clone().add(dir.clone().multiplyScalar(-.58));const normal=new THREE.Vector3(-dir.y,dir.x,0);for(let j=0;j<14;j++){const lane=(j-6.5)*.035,seed=k*31+j*7;const p1=start.clone().lerp(anchor,.27).add(normal.clone().multiplyScalar(.18*Math.sin(seed)+lane));const p2=start.clone().lerp(anchor,.55).add(normal.clone().multiplyScalar(.42*Math.sin(seed*.37)+lane*1.8));const p3=start.clone().lerp(anchor,.78).add(normal.clone().multiplyScalar(.25*Math.cos(seed*.29)+lane));p1.z+=(j%3-1)*.12;p2.z+=(j%5-2)*.16;p3.z+=(j%4-1.5)*.1;highways.push({curve:new THREE.CatmullRomCurve3([start,p1,p2,p3,anchor],false,'centripetal'),color:j%7===0?new THREE.Color(n.tone).lerp(new THREE.Color('#d8faff'),.28).getStyle():n.tone,phase:(k*14+j)*.137,width:j%7===0?.010:.006+(j%3)*.002,speed:.075+(j%5)*.011,opacity:j%7===0?.36:.19+(j%4)*.035,hubId:n.id,laneIndex:j,hubIndex:k})}});return highways}
function deformRiverPoint(h:Highway,q:number,t:number,out=new THREE.Vector3()){
 const base=h.curve.getPoint(q,out), originalEnd=h.curve.getPoint(1), liveEnd=currentNodePosition(h.hubId);
 // v0.0.30: the complete river reflows toward the live orbital ecosystem anchor.
 base.add(liveEnd.sub(originalEnd).multiplyScalar(q*q*(3-2*q)));
 const tangent=h.curve.getTangent(q).normalize();
 const normal=new THREE.Vector3(-tangent.y,tangent.x,.10*Math.sin(h.hubIndex*.9)).normalize();
 const env=Math.sin(Math.PI*q), seed=h.hubIndex*1.713;
 // Slow bundle-scale motion: the bright backbone visibly bends, breathes and shears.
 const wave=Math.sin(t*.46+seed+q*4.4)*.115;
 const breathe=Math.sin(t*.19+seed*.7)*.055;
 const shear=Math.sin(t*.31+seed*.43+q*2.15)*.070;
 const depth=(Math.cos(t*.37+seed+q*5.8)*.095+Math.sin(t*.16+seed*.31)*.045)*env;
 return base.addScaledVector(normal,(wave+breathe+shear)*env).setZ(base.z+depth);
}
function DynamicRiver({h,index,activeId,quality='BALANCED'}:{h:Highway;index:number;activeId:string|null;quality?:'HIGH'|'BALANCED'|'LOW'}){
 const sampleCount=quality==='HIGH'?42:quality==='BALANCED'?32:24, acc=useRef(0);
 const updateHz=quality==='HIGH'?26:quality==='BALANCED'?22:16;
 const halo=useRef<THREE.BufferGeometry>(null!),body=useRef<THREE.BufferGeometry>(null!),core=useRef<THREE.BufferGeometry>(null!),filament=useRef<THREE.BufferGeometry>(null!);
 const haloMat=useRef<THREE.MeshBasicMaterial>(null!),bodyMat=useRef<THREE.MeshBasicMaterial>(null!),coreMat=useRef<THREE.MeshBasicMaterial>(null!),filamentMat=useRef<THREE.MeshBasicMaterial>(null!);
 const arrays=useMemo(()=>({halo:new Float32Array(sampleCount*2*3),body:new Float32Array(sampleCount*2*3),core:new Float32Array(sampleCount*2*3),filament:new Float32Array(sampleCount*2*3)}),[sampleCount]);
 const scratch=useMemo(()=>({normal:new THREE.Vector3()}),[]);
 const indices=useMemo(()=>{const a:number[]=[];for(let i=0;i<sampleCount-1;i++){const k=i*2;a.push(k,k+1,k+2,k+1,k+3,k+2)}return a},[sampleCount]);
 const update=(geo:THREE.BufferGeometry|null,arr:Float32Array,width:number,t:number,phase:number)=>{if(!geo)return;for(let j=0;j<sampleCount;j++){const q=j/(sampleCount-1),p=deformRiverPoint(h,q,t+phase),tan=h.curve.getTangent(q).normalize(),n=scratch.normal.set(-tan.y,tan.x,.025*Math.sin(q*8+phase)).normalize();const pulse=1+.16*Math.sin(t*1.7+q*12+phase);n.multiplyScalar(width*Math.sin(Math.PI*q)*pulse);const o=j*6;arr[o]=p.x+n.x;arr[o+1]=p.y+n.y;arr[o+2]=p.z+n.z;arr[o+3]=p.x-n.x;arr[o+4]=p.y-n.y;arr[o+5]=p.z-n.z}const attr=geo.getAttribute('position') as THREE.BufferAttribute;attr.needsUpdate=true;geo.computeBoundingSphere()};
 useFrame((state,delta)=>{const t=state.clock.elapsedTime,focused=!activeId||activeId===h.hubId,energy=.80+Math.sin(t*.72+index*.91)*.20;if(haloMat.current)haloMat.current.opacity=(focused?.18:.024)*energy;if(bodyMat.current)bodyMat.current.opacity=(focused?.28:.035)*(.9+Math.sin(t*.93+index)*.1);if(coreMat.current)coreMat.current.opacity=(focused?1.0:.11)*(.88+Math.sin(t*1.31+index*.63)*.12);if(filamentMat.current)filamentMat.current.opacity=(focused?1.0:.10)*(.72+.28*Math.sin(t*2.8+index));acc.current+=delta;if(acc.current<1/updateHz)return;acc.current=0;update(halo.current,arrays.halo,.125,t,.18);update(body.current,arrays.body,.055,t,.08);update(core.current,arrays.core,.027,t,0);update(filament.current,arrays.filament,.019,t,1.35)});
 const focused=!activeId||activeId===h.hubId,accent=h.color,coreColor=new THREE.Color(accent).lerp(new THREE.Color('#e9ffff'),.36).getStyle();
 const layer=(ref:React.RefObject<THREE.BufferGeometry>,matRef:React.RefObject<THREE.MeshBasicMaterial>,arr:Float32Array,color:string,opacity:number)=><mesh><bufferGeometry ref={ref}><bufferAttribute attach="attributes-position" args={[arr,3]}/><bufferAttribute attach="index" args={[new Uint16Array(indices),1]}/></bufferGeometry><meshBasicMaterial ref={matRef} color={color} transparent opacity={opacity} depthWrite={false} side={THREE.DoubleSide} blending={THREE.AdditiveBlending}/></mesh>;
 return <group>{layer(halo,haloMat,arrays.halo,accent,focused?.075:.012)}{layer(body,bodyMat,arrays.body,accent,focused?.115:.018)}{layer(core,coreMat,arrays.core,coreColor,focused?.88:.065)}{layer(filament,filamentMat,arrays.filament,accent,focused?.86:.04)}</group>
}
function RiverBackbones({activeId,quality='BALANCED'}:{activeId:string|null;quality?:'HIGH'|'BALANCED'|'LOW'}){const highways=useMemo(()=>makeHighways(),[]);const leaders=useMemo(()=>nodes.map(n=>highways.find(h=>h.hubId===n.id&&h.laneIndex===0)!).filter(Boolean),[highways]);return <group>{leaders.map((h,i)=><DynamicRiver key={h.hubId} h={h} index={i} activeId={activeId} quality={quality}/>)}</group>}
function FlowLane({h,activeId}:{h:Highway;activeId:string|null}){const geo=useMemo(()=>new THREE.TubeGeometry(h.curve,56,h.width,4,false),[h]);const focused=!activeId||activeId===h.hubId;return <mesh geometry={geo}><meshBasicMaterial color={h.color} transparent opacity={h.opacity*(focused?(activeId ? .48 : .26):.06)} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>}
function PacketSwarm({highways,activeId,quality='BALANCED'}:{highways:Highway[];activeId:string|null;quality?:'HIGH'|'BALANCED'|'LOW'}){const ref=useRef<THREE.InstancedMesh>(null!);const active=useMemo(()=>{const step=quality==='HIGH'?4:quality==='BALANCED'?5:7;return highways.filter((_,i)=>i%step===0)},[highways,quality]);const dummy=useMemo(()=>new THREE.Object3D(),[]),last=useRef(0);useFrame(s=>{const mesh=ref.current;if(!mesh)return;const t=s.clock.elapsedTime,updateHz=quality==='HIGH'?60:quality==='BALANCED'?40:30;if(t-last.current<1/updateHz)return;last.current=t;active.forEach((h,i)=>{const boost=activeId===h.hubId?1.9:activeId?0.72:1;const q=(t*h.speed*1.12*boost+h.phase)%1;const leader=h.laneIndex===0;if(leader)dummy.position.copy(deformRiverPoint(h,q,t));else{const p=h.curve.getPoint(q),end=h.curve.getPoint(1),live=currentNodePosition(h.hubId);dummy.position.copy(p.add(live.sub(end).multiplyScalar(q*q*(3-2*q))))};const pulse=.72+Math.sin(t*2.4+i)*.18;dummy.scale.setScalar(pulse);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix)});mesh.instanceMatrix.needsUpdate=true});return <instancedMesh ref={ref} args={[undefined,undefined,active.length]} frustumCulled><sphereGeometry args={[.034,6,6]}/><meshBasicMaterial color="#bff7ff" transparent opacity={.82} depthWrite={false} blending={THREE.AdditiveBlending}/></instancedMesh>}

type DynamicLane={h:Highway;points:THREE.Vector3[];normal:THREE.Vector3;seed:number};
function DynamicStreamField({highways,activeId,quality='BALANCED'}:{highways:Highway[];activeId:string|null;quality?:'HIGH'|'BALANCED'|'LOW'}){
 const lineRefs=useRef<(THREE.Line|null)[]>([]),acc=useRef(0);
 const sampleCount=quality==='HIGH'?28:quality==='BALANCED'?22:16; const updateHz=quality==='HIGH'?36:quality==='BALANCED'?28:20;
 const lanes=useMemo<DynamicLane[]>(()=>highways.map((h,i)=>{const points=Array.from({length:sampleCount},(_,j)=>h.curve.getPoint(j/(sampleCount-1)));const a=points[0],b=points[points.length-1],d=b.clone().sub(a).normalize();return {h,points,normal:new THREE.Vector3(-d.y,d.x,.18*Math.sin(i*.71)).normalize(),seed:i*1.731}}),[highways,sampleCount]);
 const geometries=useMemo(()=>lanes.map(l=>{const g=new THREE.BufferGeometry();const a=new Float32Array(l.points.length*3);l.points.forEach((p,i)=>{a[i*3]=p.x;a[i*3+1]=p.y;a[i*3+2]=p.z});g.setAttribute('position',new THREE.BufferAttribute(a,3));return g}),[lanes]);
 const lines=useMemo(()=>lanes.map((l,i)=>{const accent=i%19===0?'#ffad62':i%13===0?'#9a7cff':i%7===0?'#e8fdff':l.h.color;return new THREE.Line(geometries[i],new THREE.LineBasicMaterial({color:accent,transparent:true,opacity:l.h.opacity,depthWrite:false,blending:THREE.AdditiveBlending}))}),[lanes,geometries]);
 useFrame((state,delta)=>{acc.current+=delta;if(acc.current<1/updateHz)return;acc.current=0;const t=state.clock.elapsedTime;lanes.forEach((l,i)=>{const line=lineRefs.current[i];if(!line)return;const pos=line.geometry.getAttribute('position') as THREE.BufferAttribute;const focus=!activeId||activeId===l.h.hubId;const amp=(.070+(i%7)*.0075)*(focus?1:.50);for(let j=0;j<l.points.length;j++){const q=j/(l.points.length-1),staticBase=l.points[j],originalEnd=l.points[l.points.length-1],liveEnd=currentNodePosition(l.h.hubId),base=staticBase.clone().add(liveEnd.sub(originalEnd).multiplyScalar(q*q*(3-2*q))),env=Math.sin(Math.PI*q);const bundle=Math.sin(t*.74+l.seed+q*5.1)*amp*1.62;const ripple=Math.sin(t*1.46+l.seed*.63+q*11.4)*amp*.68;const breathe=Math.sin(t*.25+l.seed*.21)*amp*.55;const shear=Math.sin(t*.43+l.seed*.37+q*3.2)*amp*.46;const lateral=(bundle+ripple+breathe+shear)*env;const depth=(Math.cos(t*.71+l.seed+q*8.2)*amp*.85+Math.sin(t*.37+l.seed*.4)*amp*.35)*env;pos.setXYZ(j,base.x+l.normal.x*lateral,base.y+l.normal.y*lateral,base.z+depth)}pos.needsUpdate=true;const mat=line.material as THREE.LineBasicMaterial;mat.opacity=(l.h.opacity*(focus?(activeId?1.65:1.15):.12))*(i%7===0?1:.82)});});
 return <group>{lines.map((line,i)=><primitive key={i} object={line} ref={(o:THREE.Line|null)=>{lineRefs.current[i]=o}} />)}</group>
}

function Junction({p,color,scale=1}:{p:THREE.Vector3;color:string;scale?:number}){return <group position={p}><mesh><sphereGeometry args={[.055*scale,10,10]}/><meshBasicMaterial color="#ffffff"/></mesh><mesh rotation={[Math.PI/2,0,0]}><torusGeometry args={[.11*scale,.009,5,32]}/><meshBasicMaterial color={color} transparent opacity={.8}/></mesh></group>}
// v0.0.39 Visual Gap Audit III — bright energy knots make the river read as a living flow rather than a bundle of thin lines.
function RiverEnergyKnots({activeId,quality='BALANCED'}:{activeId:string|null;quality?:'HIGH'|'BALANCED'|'LOW'}){
 const leaders=useMemo(()=>{const all=makeHighways();return nodes.map(n=>all.find(h=>h.hubId===n.id&&h.laneIndex===0)!).filter(Boolean)},[]);
 const perRiver=quality==='HIGH'?4:quality==='BALANCED'?3:2,ref=useRef<THREE.InstancedMesh>(null!),dummy=useMemo(()=>new THREE.Object3D(),[]),last=useRef(0);
 useFrame(st=>{const t=st.clock.elapsedTime, hz=quality==='HIGH'?36:quality==='BALANCED'?28:20;if(t-last.current<1/hz)return;last.current=t;let k=0;leaders.forEach((h,ri)=>{for(let j=0;j<perRiver;j++){const focus=!activeId||activeId===h.hubId,q=(t*(.055+ri*.004)+j/perRiver+ri*.071)%1;dummy.position.copy(deformRiverPoint(h,q,t+.12*j));const envelope=.45+.55*Math.sin(Math.PI*q),pulse=.70+.30*Math.sin(t*2.2+ri+j*1.7);dummy.scale.setScalar((focus?.045:.018)*envelope*pulse);dummy.updateMatrix();ref.current.setMatrixAt(k++,dummy.matrix)}});ref.current.instanceMatrix.needsUpdate=true});
 return <instancedMesh ref={ref} args={[undefined,undefined,leaders.length*perRiver]} frustumCulled><sphereGeometry args={[1,8,8]}/><meshBasicMaterial color="#b8f7ff" transparent opacity={.66} depthWrite={false} blending={THREE.AdditiveBlending}/></instancedMesh>
}
function RiverPulseTrain({activeId,quality='BALANCED'}:{activeId:string|null;quality?:'HIGH'|'BALANCED'|'LOW'}){
 const highways=useMemo(()=>makeHighways(),[]),leaders=useMemo(()=>nodes.map(n=>highways.find(h=>h.hubId===n.id&&h.laneIndex===0)!).filter(Boolean),[highways]);
 const perRiver=quality==='HIGH'?3:quality==='BALANCED'?2:1,total=leaders.length*perRiver;
 const aura=useRef<THREE.InstancedMesh>(null!),glow=useRef<THREE.InstancedMesh>(null!),core=useRef<THREE.InstancedMesh>(null!),trail=useRef<THREE.InstancedMesh>(null!);
 const d=useMemo(()=>new THREE.Object3D(),[]),last=useRef(0),c=useMemo(()=>new THREE.Color(),[]);
 useFrame(st=>{const t=st.clock.elapsedTime,hz=quality==='HIGH'?44:quality==='BALANCED'?34:24;if(t-last.current<1/hz)return;last.current=t;let k=0;
  leaders.forEach((h,ri)=>{for(let j=0;j<perRiver;j++){const focus=!activeId||activeId===h.hubId,q=(t*(.105+ri*.004)+j/perRiver+ri*.083)%1,p=deformRiverPoint(h,q,t),q2=Math.min(.999,q+.018),ahead=deformRiverPoint(h,q2,t),pulse=.86+.22*Math.sin(t*4.6+ri*1.7+j*2.2),env=.62+.38*Math.sin(Math.PI*q);c.set(h.color);
   d.position.copy(p);d.quaternion.identity();d.scale.setScalar((focus?.105:.038)*pulse*env);d.updateMatrix();aura.current?.setMatrixAt(k,d.matrix);if(aura.current)aura.current.setColorAt(k,c);
   d.scale.setScalar((focus?.060:.024)*pulse*env);d.updateMatrix();glow.current?.setMatrixAt(k,d.matrix);if(glow.current)glow.current.setColorAt(k,c);
   d.scale.setScalar((focus?.025:.011)*(1+.16*Math.sin(t*7+j)));d.updateMatrix();core.current?.setMatrixAt(k,d.matrix);
   d.position.copy(p).lerp(ahead,.42);d.lookAt(ahead);d.scale.set((focus?.028:.010)*env,(focus?.028:.010)*env,(focus?.22:.07)*pulse);d.updateMatrix();trail.current?.setMatrixAt(k,d.matrix);if(trail.current)trail.current.setColorAt(k,c);k++;
  }});
  [aura.current,glow.current,core.current,trail.current].forEach(m=>{if(!m)return;m.instanceMatrix.needsUpdate=true;if(m.instanceColor)m.instanceColor.needsUpdate=true});
 });
 const sphere=<sphereGeometry args={[1,10,8]}/>;
 return <group>
  <instancedMesh ref={aura} args={[undefined,undefined,total]} frustumCulled={false}>{sphere}<meshBasicMaterial vertexColors transparent opacity={.16} depthWrite={false} blending={THREE.AdditiveBlending}/></instancedMesh>
  <instancedMesh ref={glow} args={[undefined,undefined,total]} frustumCulled={false}><sphereGeometry args={[1,10,8]}/><meshBasicMaterial vertexColors transparent opacity={.72} depthWrite={false} blending={THREE.AdditiveBlending}/></instancedMesh>
  <instancedMesh ref={core} args={[undefined,undefined,total]} frustumCulled={false}><sphereGeometry args={[1,8,6]}/><meshBasicMaterial color="#ffffff" transparent opacity={.96} depthWrite={false} blending={THREE.AdditiveBlending}/></instancedMesh>
  <instancedMesh ref={trail} args={[undefined,undefined,total]} frustumCulled={false}><sphereGeometry args={[1,7,5]}/><meshBasicMaterial vertexColors transparent opacity={.28} depthWrite={false} blending={THREE.AdditiveBlending}/></instancedMesh>
 </group>
}
function SpatialHighways({activeId,mobile=false,quality='BALANCED'}:{activeId:string|null;mobile?:boolean;quality?:'HIGH'|'BALANCED'|'LOW'}){const highways=useMemo(()=>makeHighways(),[]);const dynamicHighways=useMemo(()=>{const step=quality==='LOW'?9:mobile?5:quality==='BALANCED'?5:2;return highways.filter((_,i)=>i%step===0)},[highways,mobile,quality]);return <group><RiverBackbones activeId={activeId} quality={quality}/>{quality!=='LOW'&&<DynamicStreamField highways={dynamicHighways} activeId={activeId} quality={quality}/>}<RiverPulseTrain activeId={activeId} quality={quality}/>{quality!=='LOW'&&<RiverEnergyKnots activeId={activeId} quality={quality}/>}<PacketSwarm highways={dynamicHighways} activeId={activeId} quality={quality}/></group>}
function CrossLinks(){const pairs:[number,number][]=nodes.map((_,i)=>[i,(i+1)%nodes.length]);return <>{pairs.map(([a,b],i)=>{const A=new THREE.Vector3(...nodes[a].pos),B=new THREE.Vector3(...nodes[b].pos),mid=A.clone().lerp(B,.5);mid.z=-.7-i*.07;const c=new THREE.QuadraticBezierCurve3(A,mid,B);return <mesh key={i} geometry={new THREE.TubeGeometry(c,36,.005,4,false)}><meshBasicMaterial color="#157ca8" transparent opacity={.15} depthWrite={false}/></mesh>})}</>}
function HierarchicalFeeds(){return <>{nodes.flatMap((n,k)=>{const hub=new THREE.Vector3(...n.pos),dir=hub.clone().normalize(),collector=hub.clone().add(dir.multiplyScalar(-.68));return topologyFor(n,k).flatMap((s,i)=>{const sub=hub.clone().add(s.p),mid=collector.clone().lerp(sub,.55);mid.z+=i%2?.26:-.18;const c=new THREE.QuadraticBezierCurve3(collector,mid,sub);const primary=<mesh key={`${n.id}-sub-${i}`} geometry={new THREE.TubeGeometry(c,28,.0045,4,false)}><meshBasicMaterial color={n.tone} transparent opacity={.28} depthWrite={false}/></mesh>;const micros=s.micro.map((m,j)=>{const world=hub.clone().add(m),mc=new THREE.QuadraticBezierCurve3(sub,sub.clone().lerp(world,.5).setZ(world.z+.12),world);return <mesh key={`${n.id}-micro-${i}-${j}`} geometry={new THREE.TubeGeometry(mc,14,.0025,3,false)}><meshBasicMaterial color={n.tone} transparent opacity={.14} depthWrite={false}/></mesh>});return [primary,...micros]})})}</>}
function EcosystemClusters(){const clusters=useMemo(()=>nodes.flatMap((n,k)=>{const base=new THREE.Vector3(...n.pos);return Array.from({length:14},(_,i)=>{const a=(i/14)*Math.PI*2+k*.23,r=1.35+(i%4)*.17;return {p:base.clone().add(new THREE.Vector3(Math.cos(a)*r,Math.sin(a)*r*.68,-.7+(i%5)*.22)),tone:n.tone,k,i}})}),[]);return <>{clusters.map((x,idx)=><group key={idx}><mesh position={x.p}><boxGeometry args={[.045,.045,.045]}/><meshBasicMaterial color={idx%9===0?'#ffffff':x.tone} transparent opacity={.55}/></mesh>{idx%3===0&&<line><bufferGeometry setFromPoints={[new THREE.Vector3(...nodes[x.k].pos),x.p]}/><lineBasicMaterial color={x.tone} transparent opacity={.08}/></line>}</group>)}</>}
function MicroNetwork(){
 const cyan=useRef<THREE.InstancedMesh>(null!),white=useRef<THREE.InstancedMesh>(null!);
 const pts=useMemo(()=>Array.from({length:190},(_,i)=>{const a=i*12.9898,b=i*78.233;return {p:new THREE.Vector3((Math.sin(a)*.5+.5)*11.4-5.7,(Math.sin(b)*.5+.5)*6.8-3.4,(Math.sin(a+b)*.5+.5)*3-2.8),white:i%7===0}}),[]);
 const groups=useMemo(()=>({cyan:pts.filter(x=>!x.white),white:pts.filter(x=>x.white)}),[pts]);
 useLayoutEffect(()=>{const d=new THREE.Object3D();const apply=(m:THREE.InstancedMesh,list:{p:THREE.Vector3;white:boolean}[])=>{list.forEach((x,i)=>{d.position.copy(x.p);const s=.72+(i%5)*.08;d.scale.setScalar(s);d.updateMatrix();m.setMatrixAt(i,d.matrix)});m.instanceMatrix.needsUpdate=true};apply(cyan.current,groups.cyan);apply(white.current,groups.white)},[groups]);
 return <group><instancedMesh ref={cyan} args={[undefined,undefined,groups.cyan.length]} frustumCulled><boxGeometry args={[.028,.028,.028]}/><meshBasicMaterial color="#168dcb" transparent opacity={.25}/></instancedMesh><instancedMesh ref={white} args={[undefined,undefined,groups.white.length]} frustumCulled><boxGeometry args={[.032,.032,.032]}/><meshBasicMaterial color="#dffcff" transparent opacity={.42}/></instancedMesh></group>
}

type InfraKind='compute'|'storage'|'gateway'|'relay';
type Infra={p:THREE.Vector3;kind:InfraKind;tone:string;scale:number;hub:number};
function cityInfra(){const out:Infra[]=[];nodes.forEach((n,k)=>{const base=new THREE.Vector3(...n.pos);for(let i=0;i<24;i++){const a=(i/24)*Math.PI*2+k*.37;const ring=i<10?1.45:i<18?2.05:2.65;const squash=.56+(k%3)*.04;const jitter=.08*Math.sin((i+1)*(k+2));const p=base.clone().add(new THREE.Vector3(Math.cos(a)*(ring+jitter),Math.sin(a)*(ring*squash+jitter*.4),-1.0+(i%6)*.16));const kinds:InfraKind[]=['compute','storage','gateway','relay'];out.push({p,kind:kinds[(i+k)%4],tone:n.tone,scale:.72+(i%5)*.13,hub:k})}});return out}
function InstancedInfrastructure(){
 const infra=useMemo(()=>cityInfra(),[]);
 const compute=useRef<THREE.InstancedMesh>(null!),storage=useRef<THREE.InstancedMesh>(null!),gateway=useRef<THREE.InstancedMesh>(null!),relay=useRef<THREE.InstancedMesh>(null!);
 const groups=useMemo(()=>({compute:infra.filter(x=>x.kind==='compute'),storage:infra.filter(x=>x.kind==='storage'),gateway:infra.filter(x=>x.kind==='gateway'),relay:infra.filter(x=>x.kind==='relay')}),[infra]);
 useLayoutEffect(()=>{const dummy=new THREE.Object3D();const apply=(ref:THREE.InstancedMesh,list:Infra[],kind:InfraKind)=>{list.forEach((x,i)=>{dummy.position.copy(x.p);dummy.rotation.set(0,(i*.73+x.hub*.31)%Math.PI,kind==='gateway'?Math.PI/4:0);const h=.18+x.scale*.22;if(kind==='compute')dummy.scale.set(.12*x.scale,h,.12*x.scale);else if(kind==='storage')dummy.scale.set(.10*x.scale,.20*x.scale,.10*x.scale);else if(kind==='gateway')dummy.scale.set(.15*x.scale,.15*x.scale,.15*x.scale);else dummy.scale.set(.035,.24*x.scale,.035);dummy.updateMatrix();ref.setMatrixAt(i,dummy.matrix);ref.setColorAt(i,new THREE.Color(x.tone))});ref.instanceMatrix.needsUpdate=true;if(ref.instanceColor)ref.instanceColor.needsUpdate=true};apply(compute.current,groups.compute,'compute');apply(storage.current,groups.storage,'storage');apply(gateway.current,groups.gateway,'gateway');apply(relay.current,groups.relay,'relay')},[groups]);
 return <group>
  <instancedMesh ref={compute} args={[undefined,undefined,groups.compute.length]} frustumCulled><boxGeometry args={[1,1,1]}/><meshStandardMaterial color="#082436" emissive="#16bde8" emissiveIntensity={.48} metalness={.7} roughness={.3} vertexColors/></instancedMesh>
  <instancedMesh ref={storage} args={[undefined,undefined,groups.storage.length]} frustumCulled><cylinderGeometry args={[1,1,1,8]}/><meshStandardMaterial color="#082436" emissive="#19c8ef" emissiveIntensity={.40} metalness={.65} roughness={.32} vertexColors/></instancedMesh>
  <instancedMesh ref={gateway} args={[undefined,undefined,groups.gateway.length]} frustumCulled><boxGeometry args={[1,1,1]}/><meshStandardMaterial color="#071d2c" emissive="#23d7ff" emissiveIntensity={.44} metalness={.72} roughness={.25} vertexColors/></instancedMesh>
  <instancedMesh ref={relay} args={[undefined,undefined,groups.relay.length]} frustumCulled><cylinderGeometry args={[1,1,1,6]}/><meshBasicMaterial color="#4adfff" transparent opacity={.42} vertexColors/></instancedMesh>
 </group>
}

// v0.0.30 Orbital Ecosystem Binding — local city/platform objects are children of each live hub orbit.
// v0.0.72: batch the 24 repeated infrastructure parts per hub into one GPU draw.
function OrbitalEcosystem({n,index,activeId}:{n:Node3D;index:number;activeId:string|null}){
 const g=useRef<THREE.Group>(null!),instances=useRef<THREE.InstancedMesh>(null!);
 const dummy=useMemo(()=>new THREE.Object3D(),[]);
 useLayoutEffect(()=>{if(!instances.current)return;for(let i=0;i<24;i++){
  const a=i/24*Math.PI*2+index*.37,ring=i<10?1.05:i<18?1.42:1.78,sc=.72+(i%5)*.13;
  dummy.position.set(Math.cos(a)*ring,Math.sin(a)*ring*.58,-.72+(i%6)*.13);
  dummy.rotation.set(0,i*.43,i%4===2?Math.PI/4:0);
  dummy.scale.set((i%4===2?.12:.09)*sc,(i%4===0?.22:.16)*sc,.09*sc);
  dummy.updateMatrix();instances.current.setMatrixAt(i,dummy.matrix);
 }instances.current.instanceMatrix.needsUpdate=true;},[index,dummy]);
 useFrame((state,delta)=>{if(!g.current)return;const t=state.clock.elapsedTime;g.current.position.copy(currentNodePosition(n.id));g.current.rotation.z=Math.sin(t*.17+index)*.025;g.current.rotation.y+=delta*.008;});
 return <group ref={g} position={currentNodePosition(n.id)} scale={!activeId||activeId===n.id?1:.93}>
  <mesh rotation={[Math.PI/2,0,0]} position={[0,0,-.82]}><ringGeometry args={[1.30,1.32,48]}/><meshBasicMaterial color={n.tone} transparent opacity={.29} side={THREE.DoubleSide}/></mesh>
  <instancedMesh ref={instances} args={[undefined,undefined,24]} frustumCulled={false}><boxGeometry args={[1,1,1]}/><meshBasicMaterial color={n.tone} transparent opacity={.68}/></instancedMesh>
 </group>
}
function OrbitalEcosystems({activeId}:{activeId:string|null}){return <>{nodes.map((n,i)=><OrbitalEcosystem key={n.id} n={n} index={i} activeId={activeId}/>)}</>}

function NetworkFloor(){const rings=useMemo(()=>[2.2,3.5,4.8,6.1],[]);return <group position={[0,0,-1.45]} rotation={[Math.PI/2,0,0]}>{rings.map((r,i)=><mesh key={r}><ringGeometry args={[r,r+.012,128]}/><meshBasicMaterial color={i%2?'#0a78a4':'#0ec4e8'} transparent opacity={.10-i*.012} side={THREE.DoubleSide}/></mesh>)}{Array.from({length:18},(_,i)=>{const a=(i/18)*Math.PI*2;return <mesh key={i} rotation={[0,0,a]} position={[3.15,0,0]}><planeGeometry args={[6.3,.008]}/><meshBasicMaterial color="#08779c" transparent opacity={.055} side={THREE.DoubleSide}/></mesh>})}</group>}
function LocalPlatforms(){return <>{nodes.map((n,k)=><group key={n.id} position={[n.pos[0],n.pos[1],-1.18]} rotation={[Math.PI/2,0,0]}><mesh><ringGeometry args={[.85,1.38,64]}/><meshBasicMaterial color={n.tone} transparent opacity={.055} side={THREE.DoubleSide}/></mesh><mesh><ringGeometry args={[1.48,1.50,64]}/><meshBasicMaterial color={n.tone} transparent opacity={.22} side={THREE.DoubleSide}/></mesh>{Array.from({length:12},(_,i)=><mesh key={i} rotation={[0,0,i*Math.PI/6]} position={[1.16,0,.01]}><planeGeometry args={[.34,.012]}/><meshBasicMaterial color={n.tone} transparent opacity={.18}/></mesh>)}</group>)}</>}
function SecondaryHighways(){const pairs:[number,number][]=nodes.map((_,i)=>[i,(i+1)%nodes.length]);return <>{pairs.map(([a,b],i)=>{const A=new THREE.Vector3(...nodes[a].pos),B=new THREE.Vector3(...nodes[b].pos);A.z=-1.02;B.z=-1.02;const mid=A.clone().lerp(B,.5);const v=B.clone().sub(A),normal=new THREE.Vector3(-v.y,v.x,0).normalize();mid.add(normal.multiplyScalar((i%2?-.24:.24)*(1+i%3*.2)));mid.z=-1.2+(i%3)*.12;const c=new THREE.QuadraticBezierCurve3(A,mid,B);return <group key={i}><mesh geometry={new THREE.TubeGeometry(c,42,.012,5,false)}><meshBasicMaterial color={i%3===0?'#29dfff':'#0b7fa8'} transparent opacity={.16} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>{[.25,.5,.75].map((t,j)=><Junction key={j} p={c.getPoint(t)} color={nodes[a].tone} scale={.55}/>)}</group>})}</>}
function CityDensity(){return <group><NetworkFloor/></group>}

function DynamicStarfield({quality='BALANCED',mobile=false}:{quality?:'HIGH'|'BALANCED'|'LOW';mobile?:boolean}){const ref=useRef<THREE.Points>(null!);const count=quality==='HIGH'?(mobile?260:520):quality==='BALANCED'?(mobile?190:360):(mobile?120:220);const data=useMemo(()=>{const p=new Float32Array(count*3),base=new Float32Array(count*3);for(let i=0;i<count;i++){const a=i*12.9898,b=i*78.233;p[i*3]=base[i*3]=(Math.sin(a)*.5+.5)*18-9;p[i*3+1]=base[i*3+1]=(Math.sin(b)*.5+.5)*10-5;p[i*3+2]=base[i*3+2]=-2-(Math.sin(a+b)*.5+.5)*8}return {p,base}},[count]);const lastStarUpdate=useRef(0);const starHz=quality==='HIGH'?30:quality==='BALANCED'?22:14;useFrame((state)=>{const t=state.clock.elapsedTime;if(t-lastStarUpdate.current<1/starHz)return;lastStarUpdate.current=t;const mesh=ref.current;if(!mesh)return;const g=mesh.geometry,a=g.getAttribute('position') as THREE.BufferAttribute;for(let i=0;i<count;i++){const z=data.base[i*3+2],depth=Math.max(.18,1-Math.abs(z)/12);a.array[i*3]=data.base[i*3]+Math.sin(t*.035+i*.37)*.09*depth;a.array[i*3+1]=data.base[i*3+1]+((t*(.018+depth*.026)+i*.013)%10)-5+Math.sin(t*.09+i)*.035;a.array[i*3+2]=z+Math.sin(t*.027+i*.21)*.08}a.needsUpdate=true;ref.current.rotation.z=Math.sin(t*.018)*.012});return <points ref={ref}><bufferGeometry><bufferAttribute attach="attributes-position" args={[data.p,3]}/></bufferGeometry><pointsMaterial color="#9defff" size={.018} transparent opacity={.48} depthWrite={false} blending={THREE.AdditiveBlending}/></points>}

// v0.0.32 Dynamic Ambient Field — no decorative scene object is intentionally static.
function DynamicAmbientField({quality='BALANCED',mobile=false}:{quality?:'HIGH'|'BALANCED'|'LOW';mobile?:boolean}){
 const shard=useRef<THREE.InstancedMesh>(null!),body=useRef<THREE.InstancedMesh>(null!);
 const shardCount=quality==='HIGH'?(mobile?24:52):quality==='BALANCED'?(mobile?17:36):(mobile?10:24);
 const bodyCount=quality==='HIGH'?(mobile?7:15):quality==='BALANCED'?(mobile?5:11):(mobile?3:7);
 const shards=useMemo(()=>Array.from({length:shardCount},(_,i)=>({a:(i/shardCount)*Math.PI*2+(i%5)*.17,r:5.1+(i%9)*.38,z:-1.2-(i%7)*.42,s:.035+(i%4)*.018,w:.018+(i%6)*.003,phase:i*.71})),[shardCount]);
 const bodies=useMemo(()=>Array.from({length:bodyCount},(_,i)=>({a:(i/bodyCount)*Math.PI*2+i*.29,r:5.4+(i%5)*.62,z:-1.5-(i%4)*.55,s:.055+(i%3)*.025,w:.010+(i%4)*.002,phase:i*1.17})),[bodyCount]);
 const dummy=useMemo(()=>new THREE.Object3D(),[]),last=useRef(0);
 const ambientHz=quality==='HIGH'?24:quality==='BALANCED'?18:12;
 useFrame((state)=>{const t=state.clock.elapsedTime;if(t-last.current<1/ambientHz)return;last.current=t;
  shards.forEach((x,i)=>{const a=x.a+t*x.w;dummy.position.set(Math.cos(a)*x.r+Math.sin(t*.13+x.phase)*.24,Math.sin(a)*x.r*.55+Math.cos(t*.11+x.phase)*.18,x.z+Math.sin(t*.17+x.phase)*.35);dummy.rotation.set(t*.09+x.phase,t*.13+i*.21,t*.07);const pulse=1+Math.sin(t*.37+x.phase)*.22;dummy.scale.set(x.s*8*pulse,x.s*3.2,x.s*3.2);dummy.updateMatrix();shard.current.setMatrixAt(i,dummy.matrix)});shard.current.instanceMatrix.needsUpdate=true;
  bodies.forEach((x,i)=>{const a=x.a-t*x.w;dummy.position.set(Math.cos(a)*x.r,Math.sin(a)*x.r*.62,x.z+Math.sin(t*.09+x.phase)*.45);dummy.rotation.set(0,t*.08+x.phase,0);const pulse=1+Math.sin(t*.21+x.phase)*.08;dummy.scale.setScalar(x.s*5*pulse);dummy.updateMatrix();body.current.setMatrixAt(i,dummy.matrix)});body.current.instanceMatrix.needsUpdate=true;
 });
 return <group>
  <instancedMesh ref={shard} args={[undefined,undefined,shardCount]} frustumCulled><boxGeometry args={[1,1,1]}/><meshBasicMaterial color="#27c9e8" transparent opacity={.20} depthWrite={false}/></instancedMesh>
  <instancedMesh ref={body} args={[undefined,undefined,bodyCount]} frustumCulled><icosahedronGeometry args={[1,1]}/><meshStandardMaterial color="#071b30" emissive="#4ddfff" emissiveIntensity={.48} transparent opacity={.42} metalness={.35} roughness={.25}/></instancedMesh>
 </group>
}

// v0.0.34 Dynamic Environment 2.0 — distant orbital colonies fill negative space without static scenery.
function DistantOrbitalColonies({quality='BALANCED',mobile=false}:{quality?:'HIGH'|'BALANCED'|'LOW';mobile?:boolean}){const groups=useRef<THREE.Group[]>([]);const count=quality==='HIGH'?(mobile?3:7):quality==='BALANCED'?(mobile?2:5):(mobile?1:3);const cfg=useMemo(()=>Array.from({length:count},(_,i)=>({r:6.2+(i%3)*1.05,a:i*2.399+0.4,y:(i%2?1:-1)*(2.4+(i%3)*.48),z:-3.8-(i%4)*.72,s:.32+(i%3)*.08,w:(i%2?-1:1)*(.018+i*.002)})),[count]);useFrame((st)=>{const t=st.clock.elapsedTime;groups.current.forEach((g,i)=>{if(!g)return;const c=cfg[i];if(!c)return;const a=c.a+t*c.w;g.position.set(Math.cos(a)*c.r,c.y+Math.sin(t*.07+i)*.22,c.z+Math.sin(a)*.55);g.rotation.y=t*(.035+i*.004);g.rotation.z=Math.sin(t*.05+i)*.16})});return <group>{cfg.map((c,i)=><group key={i} ref={g=>{if(g)groups.current[i]=g;else groups.current.splice(i,1)}} scale={c.s}><mesh><icosahedronGeometry args={[.48,1]}/><meshStandardMaterial color="#061521" emissive={i%2?"#24cce8":"#477cff"} emissiveIntensity={.38} metalness={.65} roughness={.26}/></mesh><mesh rotation={[Math.PI/2.25,i*.18,0]}><torusGeometry args={[.82,.018,6,48]}/><meshBasicMaterial color={i%2?"#24cce8":"#5c86ff"} transparent opacity={.25} depthWrite={false}/></mesh>{[0,1,2].map(j=><mesh key={j} position={[Math.cos(j*2.094)*(.9+j*.12),Math.sin(j*2.094)*(.42+j*.06),.05*j]}><octahedronGeometry args={[.09+j*.02,0]}/><meshBasicMaterial color={j===0?"#d9fbff":"#26c8e8"} transparent opacity={.56}/></mesh>)}</group>)}</group>}


// v0.0.37 Composition & Depth Pass — sparse, moving foreground silhouettes create depth without static scenery.
function ForegroundParallaxField({quality='BALANCED',mobile=false}:{quality?:'HIGH'|'BALANCED'|'LOW';mobile?:boolean}){
 const ref=useRef<THREE.InstancedMesh>(null!);const dummy=useMemo(()=>new THREE.Object3D(),[]);
 const count=quality==='HIGH'?(mobile?4:9):quality==='BALANCED'?(mobile?3:6):(mobile?2:4);
 const cfg=useMemo(()=>Array.from({length:count},(_,i)=>({x:(i%2?1:-1)*(5.7+(i%4)*.72),y:-3.0+(i%5)*1.48,z:1.0+(i%3)*.48,s:.22+(i%4)*.10,phase:i*.91,speed:.035+(i%3)*.008})),[count]);
 const last=useRef(0),updateHz=quality==='HIGH'?24:quality==='BALANCED'?18:12;useFrame((st)=>{const t=st.clock.elapsedTime;if(t-last.current<1/updateHz)return;last.current=t;cfg.forEach((c,i)=>{dummy.position.set(c.x+Math.sin(t*c.speed+c.phase)*.62,c.y+Math.cos(t*c.speed*.77+c.phase)*.34,c.z+Math.sin(t*.05+c.phase)*.22);dummy.rotation.set(t*.035+c.phase,t*.05+i*.23,t*.027);const pulse=1+Math.sin(t*.11+c.phase)*.06;dummy.scale.set(c.s*1.8*pulse,c.s*.72,c.s*.72);dummy.updateMatrix();ref.current.setMatrixAt(i,dummy.matrix)});ref.current.instanceMatrix.needsUpdate=true});
 return <instancedMesh ref={ref} args={[undefined,undefined,count]} frustumCulled><dodecahedronGeometry args={[1,0]}/><meshStandardMaterial color="#01060c" emissive="#07536c" emissiveIntensity={.075} metalness={.72} roughness={.40} transparent opacity={.25}/></instancedMesh>
}

// v0.0.37 Mid-depth relay halos keep the network visually connected outside the seven main hubs.
function MidDepthRelays({quality='BALANCED',mobile=false}:{quality?:'HIGH'|'BALANCED'|'LOW';mobile?:boolean}){const roots=useRef<THREE.Group[]>([]),last=useRef(0);const count=quality==='HIGH'?(mobile?5:12):quality==='BALANCED'?(mobile?4:8):(mobile?2:5);const cfg=useMemo(()=>Array.from({length:count},(_,i)=>({a:i*2.399+.3,r:4.8+(i%4)*.7,z:-1.8-(i%3)*.38,s:.10+(i%3)*.025,w:(i%2?1:-1)*(.018+(i%4)*.003)})),[count]);const updateHz=quality==='HIGH'?30:quality==='BALANCED'?20:14;useFrame(st=>{const t=st.clock.elapsedTime;if(t-last.current<1/updateHz)return;last.current=t;roots.current.forEach((g,i)=>{if(!g)return;const c=cfg[i];if(!c)return;const a=c.a+t*c.w;g.position.set(Math.cos(a)*c.r,Math.sin(a)*c.r*.55+Math.sin(t*.07+i)*.15,c.z);g.rotation.z=-a*.35;g.rotation.y=t*.08})});return <group>{cfg.map((c,i)=><group key={i} ref={g=>{if(g)roots.current[i]=g;else roots.current.splice(i,1)}} scale={c.s}><mesh><icosahedronGeometry args={[1,1]}/><meshBasicMaterial color={i%3===0?'#bfefff':'#22bddd'} transparent opacity={.30}/></mesh><mesh rotation={[Math.PI/2,0,0]}><torusGeometry args={[1.75,.035,6,40]}/><meshBasicMaterial color="#1bc5e6" transparent opacity={.11} depthWrite={false}/></mesh></group>)}</group>}

// v0.0.39: low-cost moving halo arcs occupy negative space without reintroducing static scenery.
function AmbientHaloArcs({quality='BALANCED',mobile=false}:{quality?:'HIGH'|'BALANCED'|'LOW';mobile?:boolean}){const roots=useRef<THREE.Mesh[]>([]);const count=quality==='HIGH'?(mobile?4:10):quality==='BALANCED'?(mobile?3:7):(mobile?2:4);const cfg=useMemo(()=>Array.from({length:count},(_,i)=>({x:(i%2?1:-1)*(4.6+(i%3)*1.05),y:-2.8+(i%5)*1.35,z:-2.2-(i%3)*.7,r:.42+(i%4)*.13,phase:i*.83,speed:(i%2?1:-1)*(.025+(i%3)*.006)})),[count]);useFrame((st,d)=>{const t=st.clock.elapsedTime;roots.current.forEach((m,i)=>{if(!m)return;const c=cfg[i];if(!c)return;m.position.set(c.x+Math.sin(t*.045+c.phase)*.35,c.y+Math.cos(t*.038+c.phase)*.22,c.z+Math.sin(t*.031+c.phase)*.18);m.rotation.x+=d*c.speed*.7;m.rotation.y+=d*c.speed;m.rotation.z=Math.sin(t*.06+c.phase)*.35;(m.material as THREE.MeshBasicMaterial).opacity=.07+.045*(.5+.5*Math.sin(t*.19+c.phase))})});return <group>{cfg.map((c,i)=><mesh key={i} ref={m=>{if(m)roots.current[i]=m;else roots.current.splice(i,1)}}><torusGeometry args={[c.r,.008,5,72,Math.PI*1.45]}/><meshBasicMaterial color={i%3===0?'#8b7cff':i%3===1?'#24d8ff':'#6ef0d1'} transparent opacity={.09} depthWrite={false} blending={THREE.AdditiveBlending}/></mesh>)}</group>}

// v0.0.66: Quality-tiered cinematic lighting. LOW avoids extra dynamic point lights.
// The metallic dock receives a cool key and contrasting violet rim; highlights stay
// below the emissive AI core so the eight stations remain readable.
function LightingHierarchy({quality}:{quality:'HIGH'|'BALANCED'|'LOW'}){
 const low=quality==='LOW';
 return <group>
  <hemisphereLight args={['#09283b','#000208',low?.10:.13]}/>
  <directionalLight position={[-5.5,6.2,7.5]} color="#b6eaff" intensity={low?.52:.72}/>
  <directionalLight position={[5.5,-2.5,2.5]} color="#6c76ff" intensity={low?.22:.38}/>
  {!low&&<pointLight position={[0,.25,3.0]} color="#3bcaff" intensity={quality==='HIGH'?1.55:1.20} distance={7.0} decay={2}/>}
  {quality==='HIGH'&&<pointLight position={[0,-.8,-1.4]} color="#8e63ff" intensity={.54} distance={6.0} decay={2}/>}
 </group>
}

function AutonomousActivity(){
 const group=useRef<THREE.Group>(null!);
 const rings=useRef<THREE.Mesh[]>([]);
 const relays=useMemo(()=>nodes.map((n,i)=>({p:new THREE.Vector3(...n.pos).multiplyScalar(.78).setZ(.35+(i%3)*.08),tone:n.tone,phase:i*.83})),[]);
 useFrame((state,delta)=>{
  const t=state.clock.elapsedTime;
  group.current.rotation.z+=delta*.006;
  rings.current.forEach((m,i)=>{if(!m)return;const q=(t*.11+i*.29)%1;m.scale.setScalar(.72+q*.95);(m.material as THREE.MeshBasicMaterial).opacity=(1-q)*.11});
 });
 return <group ref={group}>{relays.map((r,i)=><group key={i} position={r.p}><mesh><sphereGeometry args={[.025,6,6]}/><meshBasicMaterial color={i%3===0?'#ffad62':r.tone} transparent opacity={.75}/></mesh><mesh ref={m=>{if(m)rings.current[i]=m}} rotation={[Math.PI/2,0,0]}><ringGeometry args={[.08,.092,24]}/><meshBasicMaterial color={r.tone} transparent opacity={.1} side={THREE.DoubleSide} depthWrite={false}/></mesh></group>)}</group>
}

function CameraRig({profile}:{profile:string}){useFrame((state,delta)=>{const p=state.pointer;const t=state.clock.elapsedTime;const aspect=state.size.width/Math.max(1,state.size.height);const mobile=profile.startsWith('mobile');const baseZ=profile==='mobile-portrait'?16.8:profile==='mobile-landscape'?13.0:profile==='laptop'?11.7:profile==='ultrawide'?10.5:profile==='uhd'?10.2:10.6;const tx=(mobile?0:p.x*(profile==='laptop'?.22:.30))+Math.sin(t*.10)*(mobile?.035:.10)+Math.sin(t*.031)*.025,ty=(mobile?0:p.y*(profile==='laptop'?.14:.19))+Math.cos(t*.085)*(mobile?.035:.07),tz=baseZ+(aspect<1.65&&!mobile?.35:0)+Math.sin(t*.13)*(mobile?.025:.06);state.camera.position.x=THREE.MathUtils.damp(state.camera.position.x,tx,3.2,delta);state.camera.position.y=THREE.MathUtils.damp(state.camera.position.y,ty,3.2,delta);state.camera.position.z=THREE.MathUtils.damp(state.camera.position.z,tz,2.2,delta);state.camera.lookAt(0,0,-.35)});return null}

export type ProjectedHub={id:string;x:number;y:number;radiusX:number;radiusY:number};
export type RenderTelemetry={fps:number;frameMs:number;calls:number;triangles:number;geometries:number;textures:number};

function ProjectionBridge({onProjection,onTelemetry,profile='fhd'}:{onProjection?:(hubs:ProjectedHub[])=>void;onTelemetry?:(t:RenderTelemetry)=>void;profile?:string}){
 const {camera,size,gl}=useThree();
 const lastProjection=useRef(0),lastTelemetry=useRef(0),frames=useRef(0),frameStart=useRef(0);
 useFrame((state,delta)=>{
  const now=state.clock.elapsedTime;
  frames.current++;
  if(onProjection&&now-lastProjection.current>.125){
   const scale=profile==='mobile-portrait'?.69:profile==='mobile-landscape'?.83:profile==='laptop'?.93:1,yoff=SCENE_Y_OFFSET+(profile==='mobile-portrait'?.24:profile==='mobile-landscape'?.12:0),mobile=profile.startsWith('mobile');const projected=nodes.map(n=>{const local=currentNodePosition(n.id).multiplyScalar(scale);local.y+=yoff;const v=local.project(camera);return {id:n.id,x:(v.x*.5+.5)*size.width,y:(-.5*v.y+.5)*size.height,radiusX:mobile?58:n.id==='data'?82:n.id==='study'?76:72,radiusY:mobile?48:n.id==='data'?62:56}});
   onProjection(projected);lastProjection.current=now;
  }
  if(onTelemetry&&now-lastTelemetry.current>.5){
   const span=Math.max(now-lastTelemetry.current,.001),fps=Math.round(frames.current/span);frames.current=0;lastTelemetry.current=now;
   const info=gl.info;
   onTelemetry({fps,frameMs:+(1000/Math.max(fps,1)).toFixed(1),calls:info.render.calls,triangles:info.render.triangles,geometries:info.memory.geometries,textures:info.memory.textures});
  }
 });return null;
}

export default function WebGLScene({activeId=null,onProjection,onTelemetry,profile='fhd',quality='BALANCED'}:{activeId?:string|null;onProjection?:(hubs:ProjectedHub[])=>void;onTelemetry?:(t:RenderTelemetry)=>void;profile?:string;quality?:'HIGH'|'BALANCED'|'LOW'}){const mobile=profile.startsWith('mobile');const baseDpr=mobile?.9:profile==='uhd'?1.0:profile==='qhd'?1.05:profile==='laptop'?1.0:1.1;const dprMax=Math.min(baseDpr,quality==='HIGH'?1.1:quality==='BALANCED'?.95:.78);const sceneScale=profile==='mobile-portrait'?.69:profile==='mobile-landscape'?.83:profile==='laptop'?.93:1;const sceneY=SCENE_Y_OFFSET+(profile==='mobile-portrait'?.24:profile==='mobile-landscape'?.12:0);return <div className="webgl"><Canvas dpr={[.72,dprMax]} camera={{position:[0,0,10.2],fov:48}} gl={{antialias:false,alpha:false,powerPreference:'high-performance',stencil:false}} onCreated={({gl,scene})=>{gl.setClearColor('#00050d',1);scene.background=new THREE.Color('#00050d')}} performance={{min:.65,max:1,debounce:180}}><ProjectionBridge onProjection={onProjection} onTelemetry={onTelemetry} profile={profile}/><CameraRig profile={profile}/><color attach="background" args={['#00050d']}/><fog attach="fog" args={['#00030a',7.4,12.9]}/><ambientLight intensity={quality==='LOW'?.22:.12}/><LightingHierarchy quality={quality}/><DynamicStarfield quality={quality} mobile={mobile}/>{quality!=='LOW'&&<DynamicAmbientField quality={quality} mobile={mobile}/>}{quality!=='LOW'&&<DistantOrbitalColonies quality={quality} mobile={mobile}/>}{quality!=='LOW'&&<MidDepthRelays quality={quality} mobile={mobile}/>}{quality!=='LOW'&&<AmbientHaloArcs quality={quality} mobile={mobile}/>}{quality!=='LOW'&&<ForegroundParallaxField quality={quality} mobile={mobile}/>}<group position={[0,sceneY,0]} scale={sceneScale}><group scale={1.045}><Core/></group><IndependentOrbitController activeId={activeId} profile={profile}/>{quality!=='LOW'&&<OrbitalEcosystems activeId={activeId}/>}<SpatialHighways activeId={activeId} mobile={mobile} quality={quality}/><AutonomousActivity/>{nodes.map((n,i)=><Hub key={n.id} n={n} index={i} activeId={activeId} quality={quality}/>)}</group>{quality!=='LOW'&&<EffectComposer multisampling={0}><Bloom luminanceThreshold={quality==='HIGH'?.67:.72} luminanceSmoothing={.38} intensity={quality==='HIGH'?(mobile?.68:.82):.54} mipmapBlur/><Vignette eskil={false} offset={.19} darkness={quality==='HIGH'?.60:.50}/></EffectComposer>}</Canvas></div>}
