# Official visual target / v0.0.57

Reference: `official-visual-target.png` (8 GitBlog hubs). This is a **design target**, not an actual browser screenshot.

## Navigation integrity
- [x] 8 main hubs: Profile, Career, Projects, Portfolio, GitHub, Expertise, Training, Archive
- [x] Sidebar uses the same data as WebGL overlay
- [x] 3D topology has eight anchors and local orbit configurations
- [ ] Confirm actual GitBlog destinations and routing (currently hash placeholders)

## Visual gap (requires real browser screenshots)
- [ ] Hub structures should resemble detailed orbital stations
- [ ] Energy rivers need more dimensional filament lighting
- [ ] Background should contain coherent mini-infrastructure instead of random fragments
- [ ] Contrast and lighting need reference-image comparison
- [ ] Responsive and runtime FPS validation

**Never claim visual parity without screenshots and runtime testing.**


### v0.0.61 Relay silhouette
- Changed: bare diamond visual replaced by a designed orbital relay satellite near each hub.
- Still to verify: actual projected scale, overlaps, FPS and cinematic target similarity in a browser.


### v0.0.62 silhouette audit
- Implemented: six-sided relay hardware replaces ambiguous tilted square; station ribs, colored strips, relay placement and reduced shell clutter.
- Still open: target image shows much more elaborate orbital docks, atmospheric light rivers and background infrastructure.
- Status: code-level change verified, screenshot parity and browser runtime **not yet verified**.


### v0.0.63 River material audit
- Changed: fourth hot filament, hub-tinted backbone, stronger centerline contrast.
- Remaining: station metallic materials, actual screenshot comparison, volumetric pulse wake and measured performance.
- Status: source implementation only; not visually verified in browser.

## v0.0.64 — user screenshot audit (2026-10-08)

| Component | Observed in v0.0.63 screenshot | v0.0.64 source change | Browser recheck |
|---|---|---|---|
| Hub station | Eight similarly shaped spherical wireframes | Menu-specific dock arms and metal chassis | Pending |
| Relay | Tiny icon-like satellites | Larger relay, moved outward | Pending |
| Background | Dense squares/fragment clutter | Reduced local sparks and struts; global field still needs optimization | Pending |
| River | Some silver cable-like backbones | Deferred to targeted river geometry/material audit | Pending |
| Labels | Text intersects structures | Requires camera projection/overlay work in v0.0.67 | Pending |
| FPS | HUD shows 14 | Do not claim improvement; measure and profile in v0.0.65 | Pending |
| Turbopack | Internal panic reported | Webpack default for dev/build | Local confirmation pending |


## v0.0.65 — Performance audit

The user screenshot for v0.0.63 showed 14 FPS in the HUD. This release introduces tier-dependent GPU/CPU workload reductions; actual improvement must be measured on the same machine and viewport. Record FPS, draw calls, triangles, quality tier and browser. The LOW tier intentionally sacrifices background debris and postprocessing while keeping the eight main stations and navigation intact.


## v0.0.68 — Target image versus v0.0.63 user screenshot (source-backed corrective pass)

| Area | Target | User's v0.0.63 screenshot | v0.0.68 corrective action | Verified in browser? |
|---|---|---|---|---|
| Eight menus | Profile, Career, Projects, Portfolio, GitHub, Expertise, Training, Archive | Eight stations visible | Navigation retained | No |
| Station architecture | Dense recognizable orbital docks | Relatively thin ring structures | Prior v0.0.64 dock arm variations retained; major fidelity gap remains | No |
| Portfolio glyph | Legible portfolio symbol | Ambiguous tilted wireframe diamonds | Replaced three wireframe squares with solid stacked data panels | No |
| Energy rivers | Strong chromatic braided energy | Silver/grey backbone appearance | Reduce body width/opacity, raise colored filament/core and lower white mix | No |
| Background | Structured sci-fi infrastructure | Excess fragments and wireframes | Prior LOW/BALANCED quality optimization retained; composition gap remains | No |
| Performance | Smooth real-time interaction | 14 FPS shown in HUD | Prior quality-tier controls retained; no benchmark available | No |

This is an evidence-limited comparison: the target image and prior user screenshot were available in the conversation, but no automated side-by-side pixel evaluation or live v0.0.68 browser screenshot has been obtained.


## v0.0.70 — Screenshot-based audit vs official target

| Element | Official target | v0.0.69 screenshot | v0.0.70 change | Browser proof |
|---|---|---|---|---|
| Hub labels | Compact floating text beside stations | Opaque cards cover station centers | Cards removed, titles above stations | Pending |
| Selection | Main core unobstructed | Center overlay obscures AI core | Right drawer on explicit selection | Pending |
| Lower HUD | Four differentiated dense instrumentation panels | Four tiny sparse panels | Larger circular FPS/frame/calls/triangles; network traffic; real resource bars; active context | Pending |
| Station geometry | Highly detailed physical metallic platforms | Sparse low-poly rings | Not addressed; next geometry pass | Pending |
| River | Bright chromatic braided energy | Silver-grey cables | Not addressed; next river pass | Pending |
| Performance | Smooth 60fps concept | LOW mode ~18-20 FPS shown | No performance improvement claimed; profiling remains P0 | Pending |

The reference is a concept illustration, not a literal performance or GPU/CPU telemetry specification. Metrics displayed in the actual app are derived from WebGL renderer instrumentation, not synthetic device usage percentages.


### v0.0.72 audit — performance-first brightness correction
Observed v0.0.71 screenshots on GTX 660 (2GB): LOW ~17–19 FPS, ~1,600+ draw calls; this is a screenshot observation, not a controlled benchmark. Repeated peripheral infrastructure and secondary river layers are now gated or instanced; 8 colored core energy backbones are brightened for LOW without bloom. Target visual fidelity is not yet met: station geometry, detailed metallic surfaces and semantic hub silhouettes still need work.
